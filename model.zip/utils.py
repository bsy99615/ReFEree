import os
import json
from generator import Generator as promptGenerator
import re
from tqdm import tqdm
from graph import tGraph
from termcolor import colored, cprint
import transformers
from transformers import AutoTokenizer, AutoModel, AutoModelForCausalLM
from sentence_transformers import util
import torch
import torch.nn.functional as F
from retry import retry
import openai
from maverick import Maverick

import time


##########################################

## Evaluation metric
from rouge_score import rouge_scorer
import evaluate
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from scipy.spatial.distance import euclidean

import numpy as np


# Rouge
def cal_rouge(ref, ans, type):
    scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
    # 점수 계산
    scores = scorer.score(ref, ans)
    if type == 'rouge1':
        rouge1_score = scores['rouge1'].fmeasure
        return round(rouge1_score, 4)
    elif type == 'rouge2':
        rouge2_score = scores['rouge2'].fmeasure
        return round(rouge2_score, 4)
    elif type == 'rougeL':
        rougeL_score = scores['rougeL'].fmeasure
        return round(rougeL_score, 4)

# Bleu
def cal_bleu(ref, ans):
    """
    ref: reference summary
    ans: generated summary
    """
    scorer = evaluate.load("bleu")
    
    # BLEU 점수 계산
    bleu_score=scorer.compute(predictions=[ans], references=[ref])["bleu"]
    
    return round(bleu_score, 4)

# Bertscore

def cal_bertscore(bert_scorer, ref, ans):
    """
    ref: reference summary
    ans: generated summary
    """
    # bert 점수 계산
    
    bertscore=bert_scorer.compute(predictions=[ans], references=[ref], model_type="distilbert-base-uncased")['f1'][0]
    
    #print(bertscore)
    
    return round(bertscore, 4)

# Meteor
def cal_meteor(meteor_scorer, ref, ans):
    """
    ref: reference summary
    ans: generated summary
    """
    #meteor_scorer = evaluate.load('meteor')
    
    # bert 점수 계산
    meteor_score=meteor_scorer.compute(predictions=[ans], references=[ref])['meteor']
    
    return round(meteor_score, 4)

# sentence-bert with cosine similarity
def cal_sentbert_cosine(sentbert_model, ref, ans):
    """
    ref: reference summary
    ans: generated summary
    """
    embeddings = sentbert_model.encode([ref, ans])
    similarity = cosine_similarity([embeddings[0]], [embeddings[1]])
    
    return round(similarity[0][0], 4)

# sentence-bert with euclidean
def cal_sentbert_euclidean(sentbert_model, ref, ans):
    """
    ref: reference summary
    ans: generated summary
    """
    embedding1 = sentbert_model.encode(ref)
    embedding2 = sentbert_model.encode(ans)
    distance = euclidean(embedding1, embedding2)
    
    return round(distance, 4)

# SIDE
DEVICE = "cpu"
checkPointFolder = "/home/sybae/Project/codesum/SIDE/model/hard-negatives/141205/" #specify the path to the best-performing checkpoint
side_tokenizer = AutoTokenizer.from_pretrained(checkPointFolder)
side_model = AutoModel.from_pretrained(checkPointFolder).to(DEVICE)

def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0]
    input_mask_expanded = attention_mask.unsqueeze(
        -1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

def side(output, code):
    
    pair = [code,output]

    encoded_input = side_tokenizer(
            pair, padding=True, truncation=True, return_tensors='pt').to(DEVICE)

    # Compute token embeddings
    with torch.no_grad():
        model_output = side_model(**encoded_input)

    # Perform pooling
    sentence_embeddings = mean_pooling(
        model_output, encoded_input['attention_mask'])

    # Normalize embeddings
    sentence_embeddings = F.normalize(sentence_embeddings, p=2, dim=1)

    sim = util.pytorch_cos_sim(
        sentence_embeddings[0], sentence_embeddings[1]).item()
    
    return sim


# LLM-as-a judge (gpt) - (zero-shot)
@retry(Exception, tries=5, delay=1, backoff=2, max_delay=120)
def llm_judge_gpt(model_name, code, summary, temperature, top_p, max_new_tokens):
    openai.api_key=chatgpt_api_key
    
    prompt = {
    "system_prompt": '''You are an expert in understanding python code. Your task is to rate the factual consistency of a summarized text generated from a python code.
Factual consistent summary guarantees that the summary remains consistent with the python code, accurately capturing its primary functionality and logic without adding any unrelated content.
Please refer to the PYTHON CODE, and the SUMMARY, and score the consistency of the summary on a scale of 1 to 5.
Generate ONLY the score. Do not include any other codes, or notes.''',
    "user_prompt": '''
### PYTHON CODE:
{x}
### SUMMARY: {text}
### SCORE:
'''
    }
    
    user_input_script=prompt['system_prompt']+prompt['user_prompt']
    user_input_script=user_input_script.replace('{x}', code)
    user_input_script=user_input_script.replace('{text}', summary)
    
    response = openai.ChatCompletion.create(
        model=model_name,
        temperature = temperature,
        top_p=top_p,
        max_tokens=max_new_tokens,
        messages=[
            {"role": "user",  
             "content": user_input_script}
        ]
    )

    output_text = response["choices"][0]["message"]["content"].strip()

    return int(output_text)


# (model, tokenizer, generated_summary, code,  0.1, 0.9, 32)
def llm_judge_others(model, tokenizer, generated_summary, code, temperature, top_p, max_new_tokens):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    
    system_prompt = f'''You are an expert in understanding python code. Your task is to rate the factual consistency of a summarized text generated from a python code.
Factual consistent summary guarantees that the summary remains consistent with the python code, accurately capturing its primary functionality and logic without adding any unrelated content.
Please refer to the PYTHON CODE, and the SUMMARY, and score the consistency of the summary on a scale of 1 to 5.
Generate ONLY the score 1, 2, 3, 4 or 5. Do not include any other codes, or notes.'''    
    user_prompt=f'''
### PYTHON CODE:
{code}
### SUMMARY: {generated_summary}
### SCORE:'''

    prompt = (
            system_prompt+
            user_prompt
        )

    inputs = tokenizer(prompt, return_tensors="pt").to(device)

    with torch.no_grad():
        output = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            top_k=50,
            top_p=top_p
        )
    
    generated_output=tokenizer.decode(output[0], skip_special_tokens=True)
    
    
    
    if 'score:' in generated_output.lower():
        generated_output=generated_output.split("### SCORE:")[-1].strip()[0]
    else:
        generated_output=generated_output.strip() 
        
    if generated_output in ['1', '2', '3', '4', '5']:
        generated_output=int(generated_output)
    else:
        generated_output=3
    
    print(generated_output)
    #generated_output=generated_output[0]
    
    
        
    # if len(generated_output)!=1:
    #     generated_output=3
    
    # else:
    #     generated_output=int(generated_output)
    
    return generated_output


# LLM-as-a judge (llama)
def llm_judge_llama(pipeline, generated_summary, code, temperature, top_p, max_new_tokens):
    system_prompt = f'''You are an expert in understanding python code. Your task is to rate the factual consistency of a summarized text generated from a python code.
Factual consistent summary guarantees that the summary remains consistent with the python code, accurately capturing its primary functionality and logic without adding any unrelated content.
Please refer to the PYTHON CODE, and the SUMMARY, and score the consistency of the summary on a scale of 1 to 5.
Generate ONLY the score 1, 2, 3, 4 or 5. Do not include any other codes, or notes.'''    
    user_prompt=f'''
### PYTHON CODE:
{code}
### SUMMARY: {generated_summary}
### SCORE:'''

    messages = [
    {"role": "system", "content": system_prompt},
    {"role": "user", "content": user_prompt},
    ]

    terminators = [
        pipeline.tokenizer.eos_token_id,
        pipeline.tokenizer.convert_tokens_to_ids("<|eot_id|>")
    ]
    
    generated_output = pipeline(
        messages,
        max_new_tokens=max_new_tokens,
        eos_token_id=terminators,
        do_sample=True,
        temperature=temperature,
        top_p=top_p,
    )
    
    generated_output=generated_output[0]["generated_text"][-1]['content'].strip()
    
    print(generated_output)
    
    if 'score:' in generated_output.lower():
        generated_output=generated_output.split(":")[-1].strip()[0]
    else:
        generated_output=generated_output.strip() 
        
    if generated_output in ['1', '2', '3', '4', '5']:
        generated_output=int(generated_output)
    else:
        generated_output=3
        
    #generated_output=generated_output[0]
    
    
        
    # if len(generated_output)!=1:
    #     generated_output=3
    
    # else:
    #     generated_output=int(generated_output)
    
    return generated_output

##########################################

# def remove_comments(code, is_sub) -> str:
#     #code = re.sub(r'#.*', '', code)
    
#     # 여러 줄 주석 제거하면서 줄 수 유지
#     def replace_multiline_comment(match):
#         return '\n' * match.group(0).count('\n')  # 주석이 포함된 줄 수만큼 개행 유지
    
#     if is_sub: # 여러 줄 주석을 유지하고 싶다면
#         code = re.sub(r'#.*', '', code)
#         code = re.sub(r'""".*?"""|\'\'\'.*?\'\'\'', replace_multiline_comment, code, flags=re.DOTALL)
#     else: # 여러 줄 주석을 제거하고 싶다면
#         code = re.sub(r'(?m)^[ \t]*#.*\n?', '', code)
#         code = re.sub(r'""".*?"""|\'\'\'.*?\'\'\'', '', code, flags=re.DOTALL)
    
#     return code

def resolve_coref(text: str):
    model = Maverick("sapienzanlp/maverick-mes-ontonotes")
    result = model.predict(text)

    tokens = result["tokens"]
    clusters = result["clusters_token_offsets"]

    resolved_tokens = tokens[:]
    for cluster in clusters:
        main = cluster[0]  # 대표 명사 (예: Barack Obama)
        for mention in cluster[1:]:
            # mention 위치를 대표 명사 토큰으로 교체
            start, end = mention
            rep_tokens = tokens[main[0]:main[1]+1]
            resolved_tokens[mention[0]] = " ".join(rep_tokens)
            for i in range(mention[0]+1, mention[1]+1):
                resolved_tokens[i] = ""

    resolved_text = " ".join(t for t in resolved_tokens if t.strip())
    return resolved_text


import numpy as np
import pandas as pd
from collections import Counter
from itertools import combinations

def nominal_metric(a, b):
    return 0 if a == b else 1

def disagreement_matrix(data, distance_fn=nominal_metric):
    n = len(data)
    if n < 2:
        return 0.0
    disagreements = 0.0
    total = 0
    for i, j in combinations(range(n), 2):
        disagreements += distance_fn(data[i], data[j])
        total += 1
    return disagreements / total if total else 0.0

def krippendorffs_alpha(data, distance_fn=nominal_metric):
    """
    data: 2D list or np.array with shape (num_raters, num_items)
    distance_fn: function defining the difference between two values
    """
    data = np.array(data)
    n_items = data.shape[1]
    
    # Step 1: Observed Disagreement Do
    Do_total = 0
    units_with_data = 0
    for col in data.T:
        ratings = [r for r in col if r is not None]
        if len(ratings) >= 2:
            Do_total += disagreement_matrix(ratings, distance_fn)
            units_with_data += 1
    Do = Do_total / units_with_data if units_with_data else 0.0

    # Step 2: Expected Disagreement De
    all_ratings = [r for r in data.flatten() if r is not None]
    counter = Counter(all_ratings)
    total = sum(counter.values())

    De = 0.0
    for (v1, v2) in combinations(counter.keys(), 2):
        De += distance_fn(v1, v2) * counter[v1] * counter[v2]
    for v in counter.keys():
        De += distance_fn(v, v) * counter[v] * (counter[v] - 1) / 2
    De *= 2 / (total * (total - 1)) if total > 1 else 0.0

    # Final α
    if De == 0:
        return 1.0  # Perfect agreement
    return 1 - Do / De



def fleiss_kappa(matrix):
    """
    Fleiss' Kappa 계산

    Parameters:
    matrix : 2D numpy array (n_items x n_categories)
        각 항목에 대해 카테고리별 평가자 수를 담은 행렬
        예: 항목 1이 세 평가자에게 2번은 'A', 1번은 'B'로 평가되었으면 [2,1,0,...]

    Returns:
    float : Fleiss' kappa 값
    """

    N, k = matrix.shape  # N: 항목 수, k: 카테고리 수
    n = np.sum(matrix[0])  # 항목당 평가자 수 (모든 항목에 동일하다고 가정)

    # 항목별 일치도 Pi 계산
    P_i = (np.sum(matrix ** 2, axis=1) - n) / (n * (n - 1))

    # 전체 평균 관측 일치도
    P_bar = np.mean(P_i)

    # 각 카테고리의 전체 비율 p_j 계산
    p_j = np.sum(matrix, axis=0) / (N * n)

    # 기대 일치도 Pe 계산
    P_e_bar = np.sum(p_j ** 2)

    # 최종 kappa
    kappa = (P_bar - P_e_bar) / (1 - P_e_bar) if (1 - P_e_bar) != 0 else 1.0
    return round(kappa, 4)
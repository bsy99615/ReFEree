cd src

for ver in laaj4
do
    for model in mistral_7B
    do
        for seed in 4
        do
            CUDA_VISIBLE_DEVICES=0 python score_baseline.py \
                --ver $ver \
                --model $model \
                --file hallucinated_benchmark.jsonl \
                --seed $seed \
                --batch 4
        done
    done
done





# for ver in laaj2_1
# do
#     for model in gpt4o-mini
#     do
#         for seed in 4
#         do
#             CUDA_VISIBLE_DEVICES=0 python score_baseline.py \
#                 --ver $ver \
#                 --model $model \
#                 --file hallucinated_benchmark.jsonl \
#                 --seed $seed \
#                 --batch 4
#         done
#     done
# done


# for ver in laaj1_1 laaj2_1 laaj4_1
# do
#     for model in gpt4.1-mini
#     do
#         for seed in 4
#         do
#             CUDA_VISIBLE_DEVICES=0 python score_baseline.py \
#                 --ver $ver \
#                 --model $model \
#                 --file hallucinated_benchmark.jsonl \
#                 --seed $seed \
#                 --batch 4
#         done
#     done
# done

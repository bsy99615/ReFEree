cd src

# seed 8 : 2-hop

for prompt_ver in ver4
do
    for model in gpt4.1-mini
    do
        for seed in 9
        do
            CUDA_VISIBLE_DEVICES=0 python score_calculation_sample.py \
                --model $model \
                --ver info_code_all_summ_seg \
                --prompt_ver $prompt_ver \
                --shot zeroshot \
                --file human_sample.jsonl \
                --select cross_internal_external \
                --seed $seed \
                --batch 2
        done
    done
done

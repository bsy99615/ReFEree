cd src


# llama3_8B_instruct codellama_7b_instruct mistral_7B qwen2_7B_instruct deepseek_coder_6.7B_instruct


for prompt_ver in ver4
do
    for model in llama3_8B_instruct
    do
        for seed in 4
        do
            CUDA_VISIBLE_DEVICES=0 python score_calculation.py \
                --model $model \
                --ver info_code_all_summ_seg \
                --prompt_ver $prompt_ver \
                --shot zeroshot \
                --file segment_level_test.jsonl \
                --seed $seed \
                --batch 4
        done
    done
done
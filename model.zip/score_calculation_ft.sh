cd src

# # ver2 ver3 ver4 ver5
for prompt_ver in ver2
do
    for model in qwen_coder_14B_instruct
    do
        for seed in 1
        do
            CUDA_VISIBLE_DEVICES=0 python score_calculation_ft.py \
                --model $model \
                --info_ver info_code \
                --prompt_ver $prompt_ver \
                --train_type c1 \
                --seed $seed \
                --batch 4 \
                --lr 1e-4 \
                --wr 0.1 \
                --epoch 5
        done
    done
done
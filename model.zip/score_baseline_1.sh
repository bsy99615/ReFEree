cd src
# rouge1 rouge2 rougeL bleu bertscore meteor sentbert_cosine sentbert_euclidean side
# laaj1, laaj2, laaj3, laaj4, laaj5, laaj6

# llama3_8B_instruct codellama_7b_instruct mistral_7B qwen2_7B_instruct deepseek_coder_6.7B_instruct qwen_coder_7B_instruct
    # 'gpt4o-mini': 'gpt-4o-mini-2024-07-18',
    # 'gpt4.1-mini': 'gpt-4.1-mini-2025-04-14'


for ver in laaj4_info
do
    for model in mistral_7B
    do
        for seed in 4
        do
            CUDA_VISIBLE_DEVICES=1 python score_baseline.py \
                --ver $ver \
                --model $model \
                --file hallucinated_benchmark.jsonl \
                --seed $seed \
                --batch 4
        done
    done
done
cd src



for prompt_ver in ver4
do
    for model in gpt4.1-mini
    do
        for seed in 8
        do
            CUDA_VISIBLE_DEVICES=0 python context_prompt_construction.py \
                --model $model \
                --ver info_code_all_summ_seg \
                --prompt_ver $prompt_ver \
                --shot zeroshot \
                --file metadata_context.jsonl \
                --seed $seed \
                --batch 2
        done
    done
done


# seed 8 : 2-hop

# for prompt_ver in ver4
# do
#     for model in gpt4.1-mini
#     do
#         for seed in 8
#         do
#             CUDA_VISIBLE_DEVICES=0 python score_calculation.py \
#                 --model $model \
#                 --ver info_code_all_summ_seg \
#                 --prompt_ver $prompt_ver \
#                 --shot zeroshot \
#                 --file segment_level_test.jsonl \
#                 --select cross_internal_external \
#                 --seed $seed \
#                 --batch 2
#         done
#     done
# done


import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, LlamaForCausalLM
from utils import *

access_token=huggingface_access_token
#torch.set_grad_enabled(False)

MODEL_CARD={
    'llama2_7B_chat': 'meta-llama/Llama-2-7b-chat-hf',
    'llama2_13B_chat': 'meta-llama/Llama-2-13b-chat-hf',    
    'llama3_8B_instruct': 'meta-llama/Meta-Llama-3-8B-Instruct', # 8k
    'codellama_7b_instruct': 'codellama/CodeLlama-7b-Instruct-hf',
    'codellama_13b_instruct': 'codellama/CodeLlama-13b-Instruct-hf',
    'mistral_7B': 'mistralai/Mistral-7B-Instruct-v0.3',
    'gemma_7B': 'google/gemma-7b-it',
    'qwen_14B_chat': 'Qwen/Qwen-14B-Chat',
    'qwen2_7B_instruct': 'Qwen/Qwen2-7B-Instruct',
    'qwen_coder_14B_instruct': 'Qwen/Qwen2.5-Coder-14B-Instruct',
    'qwen_coder_7B_instruct': 'Qwen/Qwen2.5-Coder-7B-Instruct',
    'qwen_coder_1.5B_instruct': 'Qwen/Qwen2.5-Coder-1.5B-Instruct',
    'deepseek_coder_16B_instruct': 'deepseek-ai/DeepSeek-Coder-V2-Lite-Instruct', # 16B
    'deepseek_coder_6.7B_instruct': 'deepseek-ai/deepseek-coder-6.7b-instruct', # 6.7B
    'deepseek_instruct_16B': 'deepseek-ai/DeepSeek-V2-Lite-Chat', # 16B
    'gpt4o-mini': 'gpt-4o-mini-2024-07-18',
    'gpt4.1-mini': 'gpt-4.1-mini-2025-04-14'
}


def llm_loading_gpu(model_name):

    MODEL = MODEL_CARD[model_name]
    tokenizer = AutoTokenizer.from_pretrained(MODEL, padding_side="left", truncation=True)
    tokenizer.pad_token = tokenizer.eos_token

    if 'llama2' in model_name:
        model = LlamaForCausalLM.from_pretrained(
            MODEL,
            torch_dtype=torch.bfloat16,
            low_cpu_mem_usage=True,
            token=access_token
        )
    elif 'llama3' in model_name:
        model = AutoModelForCausalLM.from_pretrained(
            MODEL,
            torch_dtype=torch.bfloat16,
            low_cpu_mem_usage=True,
            token=access_token
        )
    
    else:    
        model = AutoModelForCausalLM.from_pretrained(
            MODEL,
            torch_dtype=torch.bfloat16,
            low_cpu_mem_usage=True
        )
        
    return model, tokenizer


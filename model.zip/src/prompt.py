## hallucinated summary generation prompt

SUMMARY_GENERATION = {
'system_prompt': '''You are an expert in understanding Python code. As a Python expert, please generate a detailed and informative summary of the following python function.
The generated summary should describe the implementation details of any methods that the function use it.
Provide ONLY the summary texts. Do not include any other codes, or notes''',
'user_prompt': '''
### Code:
{x}
### Response:
# '''
}

HALLUCINATED_SUMMARY_PROMPT = {
"system_prompt": '''You are an expert in understanding Java code. As a Java expert, please generate a detailed and informative hallucinated summary of the following Java code.
The hallucinated summary contains context that sounds plausible but does not accurately reflect the actual implementation or behavior of the code.
You SHOULD generate a summary that includes at lease one (one or more) hallucinated sentences corresponding explicitly to one of the following four factual inconsistency cases, respectively.:

The summary contains name inconsistency that the name of a function, class, or variable mentioned in the text does not match the actual identifier used in the code.
### RELATED INFORMATION:
import java.util.regex.Matcher;

public static String replaceMultilineComment(Matcher match) {
    String matched = match.group(0);
    int newlines = 0;
    for (int i = 0; i < matched.length(); i++) {
        if (matched.charAt(i) == '\n') {
            newlines++;
        }
    }
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < newlines; i++) {
        sb.append('\n');
    }
    return sb.toString();
}
### JAVA CODE:
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public static String removeComments(String code, boolean isSub) {
    if (isSub) {
        // remove inline comments starting with //
        code = code.replaceAll("//.*", "");
        // replace multiline block comments with the same number of newline characters
        Pattern pattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
        Matcher matcher = pattern.matcher(code);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String replacement = replaceMultilineComment(matcher);
            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(sb);
        code = sb.toString();
    } else {
        // remove full-line comments starting with //
        code = code.replaceAll("(?m)^[ \\t]*//.*\\n?", "");
        // completely remove multiline block comments
        Pattern pattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
        code = pattern.matcher(code).replaceAll("");
    }
    return code;
}
### HALLUCINATED SENTENCE: If is_sub is True, it removes inline comments and replaces multiline string literals with an equivalent number of newline characters using replace_line_comment function.

The summary contains type inconsistency that the described return type or variable type in the text is inconsistent with the actual type used or inferred in the code.
### RELATED INFORMATION:
import java.util.regex.Matcher;

public static String replaceMultilineComment(Matcher match) {
    String matched = match.group(0);
    int newlines = 0;
    for (int i = 0; i < matched.length(); i++) {
        if (matched.charAt(i) == '\n') {
            newlines++;
        }
    }
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < newlines; i++) {
        sb.append('\n');
    }
    return sb.toString();
}
### JAVA CODE:
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public static String removeComments(String code, boolean isSub) {
    if (isSub) {
        code = code.replaceAll("//.*", "");
        Pattern pattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
        Matcher matcher = pattern.matcher(code);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String replacement = replaceMultilineComment(matcher);
            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(sb);
        code = sb.toString();
    } else {
        code = code.replaceAll("(?m)^[ \\t]*//.*\\n?", "");
        Pattern pattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
        code = pattern.matcher(code).replaceAll("");
    }
    return code;
}
### HALLUCINATED SENTENCE: The remove_comments function returns the list type of the input code.

The summary contains functionality inconsistency that the described functionality or purpose of the code does not accurately reflect what the code actually implements.
### RELATED INFORMATION:
import java.util.regex.Matcher;

public static String replaceMultilineComment(Matcher match) {
    String matched = match.group(0);
    int newlines = 0;
    for (int i = 0; i < matched.length(); i++) {
        if (matched.charAt(i) == '\n') {
            newlines++;
        }
    }
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < newlines; i++) {
        sb.append('\n');
    }
    return sb.toString();
}
### JAVA CODE:
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public static String removeComments(String code, boolean isSub) {
    if (isSub) {
        code = code.replaceAll("//.*", "");
        Pattern pattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
        Matcher matcher = pattern.matcher(code);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String replacement = replaceMultilineComment(matcher);
            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(sb);
        code = sb.toString();
    } else {
        code = code.replaceAll("(?m)^[ \\t]*//.*\\n?", "");
        Pattern pattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
        code = pattern.matcher(code).replaceAll("");
    }
    return code;
}
### HALLUCINATED SENTENCE: The replace_multiline_comment function takes a regular expression match object containing a multiline string and returns a cleaned-up version of the comment.

The summary contains irrelevant context that the explanation contains content that is unrelated to the given code or its logical context.
## RELATED INFORMATION:
import java.util.regex.Matcher;

public static String replaceMultilineComment(Matcher match) {
    String matched = match.group(0);
    int newlines = 0;
    for (int i = 0; i < matched.length(); i++) {
        if (matched.charAt(i) == '\n') {
            newlines++;
        }
    }
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < newlines; i++) {
        sb.append('\n');
    }
    return sb.toString();
}
### JAVA CODE:
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public static String removeComments(String code, boolean isSub) {
    if (isSub) {
        code = code.replaceAll("//.*", "");
        Pattern pattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
        Matcher matcher = pattern.matcher(code);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String replacement = replaceMultilineComment(matcher);
            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(sb);
        code = sb.toString();
    } else {
        code = code.replaceAll("(?m)^[ \\t]*//.*\\n?", "");
        Pattern pattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
        code = pattern.matcher(code).replaceAll("");
    }
    return code;
}
### HALLUCINATED SENTENCE: The function is often used in machine learning pipelines and CI/CD systems for code normalization, deobfuscation, and automated documentation processing.
You should try your best to make the hallucinated summary. Provide ONLY the summary texts. Do not include any other codes, or notes.
''',
"user_prompt": '''
### RELATED INFORMATION:
{x1}
### JAVA CODE:
{x2}
### HALLUCINATED SUMMARY:
'''
}


# Factual Consistency Labeling prompt
Role = ['Code Editor', 'Code Reviewer', 'Original Code Author']



LLM_LABELING_PROMPT = {
"system_prompt": '''As a {role}, your task is to rate the factual consistency of a summarized text generated from a python code and related information.
Factual Consistency: Guarantee that the summary remains consistent with the PYYHON CODE and RELATED INFORMATION, accurately capturing its primary functionality and logic without adding any unrelated content.
Please refer to the PYTHON CODE, RELATED INFORMATION, and the SUMMARY, and then assign a factual consistency score based on the following grading rubric:

# SCORE RUBRIC:
Score Factual Consistency according to the following grading rubric:
- 5: Highly Consistent : All information in the generated content can be verified in the PYTHON CODE and RELATED INFORMATION.
- 4: Very Consistent : Most information in the generated content can be verified in the PYTHON CODE and RELATED INFORMATION, with one minor item that wouldn’t negatively impact the reader’s understanding.
- 3: Moderately Consistent : More than one piece of information in the generated content cannot be verified in the PYTHON CODE and RELATED INFORMATION, but none of these inaccuracies would negatively impact the reader’s understanding.
- 2: Somewhat Consistent : One or more pieces of information in the generated content are factually inaccurate and cannot be verified in the PYTHON CODE and RELATED INFORMATION, some, or all of which would negatively impact the reader’s understanding.
- 1: Highly Inconsistent : Most or all of the information in the generated content is inaccurate, cannot be verified in the PYTHON CODE and RELATED INFORMATION, and would negatively impact the reader’s understanding.

Generate ONLY the score. Do not include any other codes, or notes.
''',
"user_prompt": '''
### RELATED INFORMATION:
{x1}
### PYTHON CODE:
{x2}
### GENERATED SUMMARY: {text}
### SCORE:
'''
}


# LLM as a Judge Prompts
# https://arxiv.org/pdf/2306.05685
# https://arxiv.org/pdf/2303.04048
# (g-eval) https://arxiv.org/pdf/2303.16634 + https://arxiv.org/pdf/2412.01333


LaaJ={
'laaj1':'''Please act as an impartial judge and evaluate the quality of the response provided by an AI assistant to the user question displayed below. 
Your evaluation should consider the factually consistency that the summary remains consistent with the original code, accurately capturing its primary functionality and logic without adding any unrelated content.
Please rate the response on a scale of 1 to 5.

### PYTHON CODE:
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):''',
'laaj1_1':'''Please act as an impartial judge and evaluate the quality of the response provided by an AI assistant to the user question displayed below. 
Your evaluation should consider the factually consistency that the summary remains consistent with the original code, accurately capturing its primary functionality and logic without adding any unrelated content.
Please rate the response on a continuous scale from 0.0 (completely inconsistent) to 1.0 (perfectly consistent).
Output only a single float number between 0.0 and 1.0 with up to two decimal places.

### PYTHON CODE:
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):''',
'laaj2':'''Score the following project level code summarization with respect to factually consistency with one to five points, where one star means “factually inconsistent” and five stars means “factually consistent”. 
Note that factual consistency measures whether the summary accurately captures its primary functionality and logic without adding any unrelated content.

### PYTHON CODE:
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):''',
'laaj2_1':'''Score the following project level code summarization with respect to factually consistency from 0.0 to 1.0 points, where 0.0 means “factually inconsistent” and 1.0 means “factually consistent”. 
Note that factual consistency measures whether the summary accurately captures its primary functionality and logic without adding any unrelated content.

### PYTHON CODE:
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):''',
'laaj3':'''You will be given one summary written for a source code. Your task is to rate the summary from factually consistency aspect.
Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

Evaluation Criteria:
Consistency (1-5) -  Guarantee that the summary remains consistent with the original code, accurately capturing its primary functionality and logic without adding any unrelated content.

### PYTHON CODE:
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):''',
'laaj4':'''You will be given one summary written for a source code. Your task is to rate the summary from factually consistency aspect.
Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

Evaluation Criteria:
Consistency (1-5) -  Guarantee that the summary remains consistent with the original code, accurately capturing its primary functionality and logic without adding any unrelated content.

Evaluation Steps:
1. Read the PYTHON CODE carefully and understand its main intent.
2. Read the code summary and check if it accurately describe the code.
3. Assign a score for factually consistency on a scale of 1 to 5, where 1 is the lowest and 5 is the highest based on the Evaluation Criteria.

### PYTHON CODE:
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):''' ,
'laaj4_1':'''You will be given one summary written for a source code. Your task is to rate the summary from factually consistency aspect.
Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

Evaluation Criteria:
Consistency (0.0-1.0) -  Guarantee that the summary remains consistent with the original code, accurately capturing its primary functionality and logic without adding any unrelated content.

Evaluation Steps:
1. Read the PYTHON CODE carefully and understand its main intent.
2. Read the code summary and check if it accurately describe the code.
3. Assign a score for factually consistency on a continuous scale from 0.0 to 1.0, where 0.0 is the lowest and 1.0 is the highest based on the Evaluation Criteria.

### PYTHON CODE:
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):''' ,
'laaj5_java':'''As a code reviewer, you ensure the factually consistency of the code summary.

You will be given one summary written for a source code. Your task is to rate the summary from factually consistency aspect.
Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

Evaluation Criteria:
Consistency (1-5) -  Guarantee that the summary remains consistent with the original code, accurately capturing its primary functionality and logic without adding any unrelated content.

Evaluation Steps:
1. Read the JAVA CODE carefully and understand its main intent.
2. Read the code summary and check if it accurately describe the code.
3. Assign a score for factually consistency on a scale of 1 to 5, where 1 is the lowest and 5 is the highest based on the Evaluation Criteria.

### JAVA CODE: 
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):''',
'laaj5':'''As a code reviewer, you ensure the factually consistency of the code summary.

You will be given one summary written for a source code. Your task is to rate the summary from factually consistency aspect.
Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

Evaluation Criteria:
Consistency (1-5) -  Guarantee that the summary remains consistent with the original code, accurately capturing its primary functionality and logic without adding any unrelated content.

Evaluation Steps:
1. Read the PYTHON CODE carefully and understand its main intent.
2. Read the code summary and check if it accurately describe the code.
3. Assign a score for factually consistency on a scale of 1 to 5, where 1 is the lowest and 5 is the highest based on the Evaluation Criteria.

### PYTHON CODE: 
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):''',
'laaj5_1':'''As a code reviewer, you ensure the factually consistency of the code summary.

You will be given one summary written for a source code. Your task is to rate the summary from factually consistency aspect.
Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

Evaluation Criteria:
Consistency (0.0-1.0) -  Guarantee that the summary remains consistent with the original code, accurately capturing its primary functionality and logic without adding any unrelated content.

Evaluation Steps:
1. Read the PYTHON CODE carefully and understand its main intent.
2. Read the code summary and check if it accurately describe the code.
3. Assign a score for factually consistency on a continuous scale from 0.0 to 1.0, where 0.0 is the lowest and 1.0 is the highest based on the Evaluation Criteria.

### PYTHON CODE: 
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):''',
'laaj6':'''You are an AI assistant acting as a static code analysis tool. Your task is to determine if a given code summary is factually consistent with the python code, that the summary remains consistent with the original code, accurately capturing its primary functionality and logic without adding any unrelated content, based on a strict set of rules.

Rules:
1. **Strict Literalism**: The summary must only contain facts that are explicitly and literally written in the code.
2. **No Inference**: Do not infer the code's purpose, intent, or outcome, even if it seems obvious. Only verify what is written.
3. **No Assumptions**: Do not use external knowledge or make assumptions about variable contents or the behavior of imported libraries.
4. **Output Format**: Your response must be on a scale of 1 to 5, where 1 is the lowest and 5 is the highest based on the Evaluation Criteria.

### PYTHON CODE:
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):'''}

# + fewshot?

# ver2 : instruction
# ver3 : instruction + criteria
# ver4 : instruction + criteria + evaluation step
# ver5 : role + instruction + criteria + evaluation step
# OURS={
# 'ver2':'''Evaluate the following project level code summary text with respect to {case} with only `1` or `0` , where `1` means “{case}” and `0` means “{case} violated”. 
# Note that {case} measures whether {explanation}.''',
# 'ver3':'''You will be given one summary text written for a source code. Your task is to evaluate the summary from {case} aspect.
# Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

# Evaluation Criteria:
# {case} (1 or 0) - Guarantee that {explanation}.''',
# 'ver4':'''You will be given one summary text written for a source code. Your task is to evaluate the summary from {case} aspect.
# Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

# Evaluation Criteria:
# {case} (1 or 0) - Guarantee that {explanation}.

# Evaluation Steps:
# 1. Read the PYTHON CODE carefully and understand its main intent.
# 2. Read the code summary text and check if it accurately describe the code.
# 3. Evaluate whether {case} exists, where `1` means “{case}” and `0` means “{case} violated” based on the Evaluation Criteria.''' ,
# 'ver5':'''As a code reviewer, you ensure the factually consistency of the code summary.
# You will be given one summary text written for a source code. Your task is to evaluate the summary from {case} aspect.
# Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

# Evaluation Criteria:
# {case} (1 or 0) - Guarantee that {explanation}.

# Evaluation Steps:
# 1. Read the PYTHON CODE carefully and understand its main intent.
# 2. Read the code summary text and check if it accurately describe the code.
# 3. Evaluate whether {case} exists, where `1` means “{case}” and `0` means “{case} violated” based on the Evaluation Criteria.'''}

# CASE = {
#     'Name consistency': 'the name of a function, class, or variable mentioned in the SUMMARY TEXT exactly match the actual identifier used in the PYTHON CODE',
#     'Type consistency': 'the described function\'s return type or variable type in the SUMMARY TEXT is consistent with the actual type used or inferred in the PYTHON CODE',
#     'Functionality consistency': 'the described functionality or purpose of the code in the SUMMARY TEXT does accurately reflect what the PYTHON CODE actually implements.',
#     'Relevant context': 'the SUMMARY TEXT does contain content that is necessary or related to the PYTHON CODE, such as not overly generalized descriptions of specific code entities or information that can not be excluded with affecting the understanding of the code'
# }

USER_PROMPT='''
### PYTHON CODE:
{x}
### SUMMARY TEXT: {text}
### SCORE (score only):'''

# inconsistency focused
OURS={
'ver2':'''Evaluate the following project level code summary text with respect to {case} with only `1` or `0` , where `1` means “{case} does not exist” and `0` means “{case} exists”. 
Note that {case} measures whether {explanation}.''',
'ver3':'''You will be given one summary text written for a source code. Your task is to evaluate the summary from {case} aspect.
Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

Evaluation Criteria:
{case} (1 or 0) - {explanation}.''',
'ver4':'''You will be given one summary text written for a source code. Your task is to evaluate the summary from {case} aspect.
Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

Evaluation Criteria:
{case} (1 or 0) - {explanation}.

Evaluation Steps:
1. Read the PYTHON CODE carefully and understand its main intent.
2. Read the code summary text and check if it accurately describe the code.
3. Evaluate whether {case} exists, where `1` means “{case} does not exist” and `0` means “{case} exists” based on the Evaluation Criteria.''' ,
'ver4_java':'''You will be given one summary text written for a source code. Your task is to evaluate the summary from {case} aspect.
Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

Evaluation Criteria:
{case} (1 or 0) - {explanation}.

Evaluation Steps:
1. Read the JAVA CODE carefully and understand its main intent.
2. Read the code summary text and check if it accurately describe the code.
3. Evaluate whether {case} exists, where `1` means “{case} does not exist” and `0` means “{case} exists” based on the Evaluation Criteria.''' ,
'ver5':'''As a code reviewer, you ensure the factually consistency of the code summary.
You will be given one summary text written for a source code. Your task is to evaluate the summary from {case} aspect.
Please make sure you read and understand these instructions carefully. Please keep this document open while reviewing, and refer to it as needed.

Evaluation Criteria:
{case} (1 or 0) - {explanation}.

Evaluation Steps:
1. Read the PYTHON CODE carefully and understand its main intent.
2. Read the code summary text and check if it accurately describe the code.
3. Evaluate whether {case} exists, where `1` means “{case} does not exist” and `0` means “{case} exists” based on the Evaluation Criteria.'''}


CASE = {
    'Name inconsistency': 'the name of a function, class, or variable mentioned in the SUMMARY TEXT does not match the actual identifier used in the PYTHON CODE',
    'Type inconsistency': 'the described function\'s return type or variable type in the SUMMARY TEXT is inconsistent with the actual type used or inferred in the PYTHON CODE',
    'Functionality inconsistency': 'the described functionality or purpose of the code in the SUMMARY TEXT does not accurately reflect what the PYTHON CODE actually implements. This typically occurs when the input code is dependent on a complex project environment or lacks enough information, leading to a misunderstanding of the actual functionality',
    'Irrelevant context': 'the SUMMARY TEXT contains content that is unnecessary or unrelated to the PYTHON CODE, such as overly generalized descriptions of specific code entities or information that can be excluded without affecting the understanding of the code'
}


# LABELING_SYSTEM_PROMPT='''You are a meticulous AI assistant acting as a static code analysis tool. 
# Your task is to determine if a given SUMMARY TEXT is factually inconsistent with the provided PYTHON CODE and RELATED INFORMATION, based on a strict set of rules.

# Rules:
# 1. **Strict Literalism**: The summary must only contain facts that are explicitly and literally written in the code.
# 2. **No Inference**: Do not infer the code's purpose, intent, or outcome, even if it seems obvious. Only verify what is written.
# 3. **No Assumptions**: Do not use external knowledge or make assumptions about variable contents or the behavior of imported libraries.
# 4. **Output Format**: Your response must be **only** `YES` or `NO`. Do not include any explanations or other text.

# Given the PYTHON CODE, RELATED INFORMATION, and the SUMMARY TEXT which is the part of the summary, your objective is to specifically evaluate whether the sentence contains {case} that {explanation}. 
# If the sentence is strictly corresponds to a {case}, you should output YES, otherwise output NO.
# '''



# Name Inconsistency
DEMON={
'Name inconsistency':'''
### Examples:

**Example 1:**
### PYTHON CODE:
class DataProcessor:
    def load_data(self, filepath: str):
        with open(filepath, "r") as f:
            return f.readlines()
### SUMMARY TEXT: The method read_data loads file content line by line.
### SCORE (score only): 0

**Example 2:**
### PYTHON CODE:
def calculate_average(values):
    if not values:
        return 0
    return sum(values) / len(values)
### SUMMARY TEXT: The function calculate_average returns the mean of a list of numbers.
### SCORE (score only): 1

**Example 3:**
### PYTHON CODE:
import json
def save_to_json(data, filename):
    with open(filename, "w") as f:
        json.dump(data, f)
### SUMMARY TEXT: The function store_json writes Python objects into a JSON file.
### SCORE (score only): 0

**Example 4:**
### PYTHON CODE:
class User:
    def __init__(self, username, email):
        self.username = username
        self.email = email
### SUMMARY TEXT: The User class constructor initializes username and email.
### SCORE (score only): 1
''',
'Type inconsistency':'''
### Examples:

**Example 1:**
### PYTHON CODE:
import json
from typing import Dict
def load_config(path: str) -> Dict[str, str]:
    with open(path, "r") as f:
        return json.load(f)
### SUMMARY TEXT: The function `load_config` returns a list of configuration values.
### SCORE (score only): 0

**Example 2:**
### PYTHON CODE:
from typing import List
def get_user_ids() -> List[int]:
    return [1, 2, 3, 4]
### SUMMARY TEXT: The function `get_user_ids` returns a list of integers representing user IDs.
### SCORE (score only): 1

**Example 3:**
### PYTHON CODE:
from datetime import datetime
def get_current_timestamp() -> str:
    return datetime.utcnow().isoformat()
### SUMMARY TEXT: he function `get_current_timestamp` returns a datetime object in UTC.
### SCORE (score only): 0

**Example 4:**
### PYTHON CODE:
from typing import Optional
def find_user_by_id(user_id: int) -> Optional[str]:
    users = {1: "alice", 2: "bob"}
    return users.get(user_id)
### SUMMARY TEXT: The function `find_user_by_id` may return either a string username or None.
### SCORE (score only): 1
''',
'Functionality inconsistency':'''
### Examples:

**Example 1:**
### PYTHON CODE:
import pandas as pd
def load_and_clean_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.dropna()
    return df
### SUMMARY TEXT: This function reads a CSV file, removes missing values, and returns the cleaned DataFrame.
### SCORE (score only): 1

**Example 2:**
### PYTHON CODE:
from fastapi import FastAPI
app = FastAPI()
@app.get("/status")
def get_status():
    return {"status": "ok"}
### SUMMARY TEXT: The code defines a FastAPI route /status that deletes a record from the database and returns success.
### SCORE (score only): 0

**Example 3:**
### PYTHON CODE:
import requests
def fetch_data(url: str):
    response = requests.get(url)
    return response.json()
### SUMMARY TEXT: This function makes a GET request to the given URL and returns the parsed JSON response.
### SCORE (score only): 1

**Example 4:**
### PYTHON CODE:
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
Base = declarative_base()
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String, nullable=False)
### SUMMARY TEXT: The User class maps to a database table called customers with fields id and username.
### SCORE (score only): 0
''',
'Irrelevant context':'''
### Examples:

**Example 1:**
import os
def get_env_variable(key: str, default: str = None):
    return os.environ.get(key, default)
### SUMMARY TEXT: This function retrieves environment variables, which is a common technique used in cloud-native applications for configuration management.
### SCORE (score only): 0

**Example 2:**
### PYTHON CODE:
from datetime import datetime
def get_current_year():
    return datetime.now().year
### SUMMARY TEXT: This function returns the current year as an integer.
### SCORE (score only): 1

**Example 3:**
### PYTHON CODE:
import hashlib
def hash_password(password: str):
    return hashlib.sha256(password.encode()).hexdigest()
### SUMMARY TEXT: This function hashes a password using SHA256, which is widely considered a secure cryptographic standard for authentication in modern web systems.
### SCORE (score only): 0

**Example 4:**
### PYTHON CODE:
import json
def load_config(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
### SUMMARY TEXT: This function loads a configuration file in JSON format, which is a popular data interchange format invented by Douglas Crockford.
### SCORE (score only): 0
''',
}

import os
import re
import json
from node_prompt import projectSearcher

try:
    import javalang
    _HAS_JAVALANG = True
except Exception:
    _HAS_JAVALANG = False

from utils import DS_BASE_DIR

# For CoderEval dataset we use a specific repo/file layout
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
DATASET_DIR = os.path.join(ROOT, 'dataset', 'CoderEval')
REPO_DIR = os.path.join(DATASET_DIR, 'repository', 'Java')
INPUT_JSON = os.path.join(DATASET_DIR, 'CoderEval4Java.json')
GRAPH_DIR = os.path.join(DATASET_DIR, 'Graph')


class JavaParser(object):
    """Minimal Java parser that extracts top-level classes, methods, fields and imports.
    It uses javalang when available and falls back to a best-effort regex extractor otherwise.
    The output schema attempts to match the python parser's structure so other tools (eg. projectSearcher)
    can work with the generated parse information.
    """
    def __init__(self):
        self._source = None

    def _read(self, fpath):
        with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()

    def _safe_position(self, node):
        # javalang nodes may carry a position tuple (line, col)
        if not hasattr(node, 'position') or node.position is None:
            return -1
        return node.position[0]

    def parse(self, java_file):
        src = self._read(java_file)
        self._source = src
        node_info = {}

        # module: the Java file itself
        node_info[''] = {"type": "Module"}

        if _HAS_JAVALANG:
            try:
                tree = javalang.parse.parse(src)
            except Exception:
                tree = None
        else:
            tree = None

        # imports
        imports = []
        if tree is not None:
            for imp in getattr(tree, 'imports', []) or []:
                path = imp.path
                imports.append(path)
                name = path.split('.')[-1]
                # store import as a variable-like node to keep compatibility
                node_info[name] = {
                    "type": "Variable",
                    "def": f"import {path}",
                    "sline": getattr(imp, 'position', (None, None))[0] if getattr(imp, 'position', None) else -1,
                    "import": [path, None]
                }

        if tree is not None:
            package = getattr(tree, 'package', None)
            if package is not None:
                node_info['']['package'] = package.name

            types = getattr(tree, 'types', []) or []
            for t in types:
                # t is ClassDeclaration or InterfaceDeclaration
                cls_name = t.name
                sline = self._safe_position(t)
                def_str = f'class {cls_name}'
                node_info[cls_name] = {
                    "type": "Class",
                    "def": def_str,
                    "sline": sline
                }

                # fields
                for field in getattr(t, 'fields', []) or []:
                    # each field may contain multiple declarators
                    for decl in getattr(field, 'declarators', []) or []:
                        field_name = f"{cls_name}.{decl.name}"
                        f_line = self._safe_position(field)
                        node_info[field_name] = {
                            "type": "Variable",
                            "def": f"{field.type.name if hasattr(field.type, 'name') else 'var'} {decl.name}",
                            "sline": f_line,
                            "in_class": cls_name
                        }

                # methods
                for m in getattr(t, 'methods', []) or []:
                    method_name = f"{cls_name}.{m.name}"
                    sig = self._get_method_signature(m)
                    lno = self._safe_position(m)
                    node_info[method_name] = {
                        "type": "Function",
                        "def": sig,
                        "sline": lno,
                        "in_class": cls_name
                    }

        else:
            # fallback: rough regex parsing if javalang is unavailable or fails
            package_pattern = re.compile(r'^\s*package\s+([\w\.]+)\s*;', re.MULTILINE)
            imp_pattern = re.compile(r'^\s*import\s+([\w\.]+)\s*;', re.MULTILINE)
            class_pattern = re.compile(r'(?:public\s+|private\s+|protected\s+|)class\s+(\w+)', re.MULTILINE)
            method_pattern = re.compile(r'(public|private|protected|static|\s)+\s*[\w<>,\s\[\]]+\s+(\w+)\s*\(', re.MULTILINE)
            field_pattern = re.compile(r'(public|private|protected|static|final|\s)+\s*[\w<>,\s\[\]]+\s+(\w+)\s*(=|;)', re.MULTILINE)

            m = package_pattern.search(src)
            if m:
                node_info['']['package'] = m.group(1)

            for imp in imp_pattern.finditer(src):
                path = imp.group(1)
                name = path.split('.')[-1]
                node_info[name] = {
                    "type": "Variable",
                    "def": f"import {path}",
                    "sline": imp.start(),
                    "import": [path, None]
                }

            classes = class_pattern.findall(src)
            for cls_name in classes:
                node_info[cls_name] = {"type": "Class", "def": f'class {cls_name}', "sline": -1}

            for field in field_pattern.findall(src):
                # field pattern groups: (modifier, name, = or ;)
                name = field[1]
                # put field under top-level class if only one
                if len(classes) == 1:
                    cls_name = classes[0]
                    node_info[f"{cls_name}.{name}"] = {
                        "type": "Variable",
                        "def": f"{name}",
                        "sline": -1,
                        "in_class": cls_name
                    }

            for method in method_pattern.findall(src):
                # method[1] is the method name
                name = method[1]
                if len(classes) == 1:
                    cls_name = classes[0]
                    node_info[f"{cls_name}.{name}"] = {
                        "type": "Function",
                        "def": f"{name}()",
                        "sline": -1,
                        "in_class": cls_name
                    }

        return node_info

    def _get_method_signature(self, mnode):
        # Build a human-readable signature string for the method
        params = []
        for p in getattr(mnode, 'parameters', []) or []:
            name = getattr(p, 'name', '')
            ptype = None
            if getattr(p, 'type', None):
                ptype = getattr(p.type, 'name', str(p.type))
            if ptype:
                params.append(f"{ptype} {name}")
            else:
                params.append(name)
        return_type = getattr(mnode, 'return_type', None)
        if return_type is not None:
            ret = getattr(return_type, 'name', str(return_type))
        else:
            ret = 'void'
        modifiers = ' '.join(getattr(mnode, 'modifiers', [])) if getattr(mnode, 'modifiers', None) else ''
        sig = f"{modifiers} {ret} {mnode.name}({', '.join(params)})"
        return sig.strip()


class projectParser(object):
    def __init__(self):
        self.java_parser = JavaParser()
        self.iden_pattern = re.compile(r'[\W]')
        self.proj_searcher = projectSearcher()
        self.proj_dir = None
        self.parse_res = None

    def set_proj_dir(self, dir_path):
        if not dir_path.endswith(os.sep):
            self.proj_dir = dir_path + os.sep
        else:
            self.proj_dir = dir_path

    def _get_all_module_path(self, target_path):
        # return dict mapping directories to their direct java children (files or subdirs)
        if not os.path.isdir(target_path):
            return {}

        dir_list = [target_path,]
        java_dict = {}
        while len(dir_list) > 0:
            jdir = dir_list.pop()
            java_dict[jdir] = set()
            for item in os.listdir(jdir):
                fpath = os.path.join(jdir, item)
                if os.path.isdir(fpath):
                    if re.search(self.iden_pattern, item) is None:
                        dir_list.append(fpath)
                        java_dict[jdir].add(fpath)
                elif os.path.isfile(fpath) and fpath.endswith('.java'):
                    if re.search(self.iden_pattern, item[:-5]) is None:
                        java_dict[jdir].add(fpath)

        return java_dict

    def _get_module_name(self, fpath):
        # For java, module name is the dotted path of the file relative to the project root
        if fpath.endswith('.java'):
            fpath = fpath[:-5]

        fpath = fpath.rstrip(os.sep)
        return fpath[len(self.proj_dir):].replace(os.sep, '.')


    def parse_dir(self, pkg_dir):
        self.set_proj_dir(pkg_dir)
        java_dict = self._get_all_module_path(pkg_dir)

        module_dict = {}
        # directories: as modules
        for dpath in java_dict:
            module = self._get_module_name(dpath)
            if len(module) > 0:
                module_dict[module] = [dpath,]

        # files
        javafiles = set()
        for java_set in java_dict.values():
            for fpath in java_set:
                if fpath.endswith('.java'):
                    javafiles.add(fpath)

        for fpath in javafiles:
            module = self._get_module_name(fpath)
            if len(module) > 0:
                if module in module_dict:
                    module_dict[module].append(fpath)
                else:
                    module_dict[module] = [fpath,]

        self.parse_res = {}
        for module, path_list in module_dict.items():
            info_dict = {}
            for fpath in path_list:
                if fpath in java_dict:
                    # directory
                    for item in java_dict[fpath]:
                        submodule = self._get_module_name(item)
                        if submodule != module:
                            info_dict[submodule] = {
                                "type": "Module",
                                "import": [submodule, None]
                            }
                else:
                    # java file
                    try:
                        info_dict.update(self.java_parser.parse(fpath))
                    except Exception:
                        # skip problematic files
                        continue
                    break

            if len(info_dict) > 0:
                self.parse_res[module] = info_dict

        self.proj_searcher.set_proj(pkg_dir, self.parse_res)
        # Optionally, we could implement cross-file resolutions here, but keep basic
        return self.parse_res


if __name__ == '__main__':
    with open(INPUT_JSON, 'r', encoding='utf-8') as f:
        ds = json.load(f)
    records = ds.get('RECORDS', [])
    pkg_set = set([x['project'] for x in records])
    print(f'There are {len(pkg_set)} repositories in CoderEval Java dataset')

    project_parser = projectParser()
    if not os.path.isdir(GRAPH_DIR):
        os.makedirs(GRAPH_DIR, exist_ok=True)

    item_num = 0
    for item in os.listdir(REPO_DIR):
        if item not in pkg_set:
            # allow partial matching if names slightly differ
            if not any([item.lower() in v.lower() or v.lower() in item.lower() for v in pkg_set]):
                continue

        dir_path = os.path.join(REPO_DIR, item)
        if os.path.isdir(dir_path):
            content = list(os.listdir(dir_path))
            if len(content) > 1:
                info = project_parser.parse_dir(dir_path)
            else:
                dist_path = os.path.join(dir_path, content[0])
                info = project_parser.parse_dir(dist_path)

            save_path = os.path.join(GRAPH_DIR, item + '.json')
            with open(save_path, 'w', encoding='utf-8') as f:
                json.dump(info, f, ensure_ascii=False, indent=2)
            item_num += 1

    print(f'Generate repo-specific context graph for {item_num} repositories.')

from argparse import ArgumentParser
from utils import *
import scipy.stats as stats


# Kendall-Tau Correlation Coefficient (τ ).
#Spearman Correlation Coefficient (ρ).

def reference_based_evaluation(dataset, metric, std_output_path1, std_output_path2):
    ''' 
    dataset: test dataset
    metric: baseline.
    '''
    scores=[]
    overall_majority_label=[]
    json_data=[]
    
    start_time=time.time()
    
    
    if metric == 'rouge1':
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_rouge(gold_summary, generated_summary, 'rouge1')
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
        
    elif metric == 'rouge2':
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']            
            score=cal_rouge(gold_summary, generated_summary, 'rouge2')
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
        
    elif metric == 'rougeL':
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']            
            score=cal_rouge(gold_summary, generated_summary, 'rougeL')
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
        
    elif metric == 'bleu':
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_bleu(gold_summary, generated_summary)
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
            
    elif metric == 'bertscore':
        bert_scorer = evaluate.load("bertscore")
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_bertscore(bert_scorer, gold_summary, generated_summary)
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })

    elif metric == 'meteor':
        meteor_scorer = evaluate.load('meteor')
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_meteor(meteor_scorer, gold_summary, generated_summary)
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
            
    elif metric == 'sentbert_cosine':
        sentbert_model = SentenceTransformer('all-MiniLM-L6-v2')
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_sentbert_cosine(sentbert_model, gold_summary, generated_summary)
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
    elif metric == 'sentbert_euclidean':
        sentbert_model = SentenceTransformer('all-MiniLM-L6-v2')
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_sentbert_euclidean(sentbert_model, gold_summary, generated_summary)
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
    
    end_time=time.time()-start_time
    print(f'{metric} score: {np.mean(scores)}')
    print(f'Time taken for {metric} evaluation: {end_time:.2f} seconds')
    
    # Correlation calculation
    
    pearson_corr1, pearson_p_val1 = stats.pearsonr(scores, overall_majority_label)
    print(f'[total_score] Pearson correlation: {pearson_corr1}, p-value: {pearson_p_val1}')
          
    spearman_corr1, spearman_p_val1 = stats.spearmanr(scores, overall_majority_label)
    print(f'[total_score] Spearman correlation: {spearman_corr1}, p-value: {spearman_p_val1}')
    
    kendall_corr1, kendall_p_val1 = stats.kendalltau(scores, overall_majority_label)
    print(f'[total_score] Kendall correlation: {kendall_corr1}, p-value: {kendall_p_val1}')
    
    print('------------')
        
    with open(std_output_path1, 'w') as f:
        f.write(f'Time taken for {metric} evaluation: {end_time:.2f} seconds\n')
        f.write(f'score: {np.mean(scores)}\n') 
        f.write(f'[total_score] Pearson correlation: {pearson_corr1}, p-value: {pearson_p_val1}\n')
        f.write(f'[total_score] Spearman correlation: {spearman_corr1}, p-value: {spearman_p_val1}\n')
        f.write(f'[total_score] Kendall correlation: {kendall_corr1}, p-value: {kendall_p_val1}\n')
        
        
    with open(std_output_path2, 'w') as f:
        for data in json_data:
            f.write( json.dumps(data, ensure_ascii=False) + "\n" )
    return 

def reference_free_evaluation(dataset, metric, info, std_output_path1, std_output_path2):
    ''' 
    dataset: test dataset
    metric: baseline.
    '''
    scores=[]
    overall_majority_label=[]
    json_data=[]
    
    start_time=time.time()
    
    if metric == 'side':
        for idx in tqdm(range(len(dataset))):
            code=remove_comments(dataset[idx]['input'], False)
            generated_summary=dataset[idx]['hallucinated_summary']
            if info=='info':
                input_information=information_prompt(idx, dataset, api_infos, args.model)
                score=side(generated_summary, input_information+code)
            else:
                score=side(generated_summary, code)
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
            

    # LLM as a judge (ChatGPT)
    elif metric == 'llm_judge_gpt_4.1_mini':
        for idx in tqdm(range(len(dataset))):
            code=remove_comments(dataset[idx]['input'], False)
            generated_summary=dataset[idx]['hallucinated_summary']
            if info=='info':
                input_information=information_prompt(idx, dataset, api_infos, args.model)
                score=llm_judge_gpt('gpt-4.1-mini-2025-04-14', generated_summary, input_information+code, 0.1, 0.9, 4)
            else:
                score=llm_judge_gpt('gpt-4.1-mini-2025-04-14', generated_summary, code, 0.1, 0.9, 4)
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
            
    elif metric == 'llm_judge_gpt_4o':
        for idx in tqdm(range(len(dataset))):
            code=remove_comments(dataset[idx]['input'], False)
            generated_summary=dataset[idx]['hallucinated_summary']
            if info=='info':
                input_information=information_prompt(idx, dataset, api_infos, args.model)
                score=llm_judge_gpt('gpt-4o-mini-2024-07-18', generated_summary, input_information+code, 0.1, 0.9, 4)
            else:
                score=llm_judge_gpt('gpt-4o-mini-2024-07-18', generated_summary, code, 0.1, 0.9, 4)
                
            scores.append(score)
            overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
        
            
    elif metric == 'llm_judge_llama3_8B_instruct':
        tokenizer = AutoTokenizer.from_pretrained('meta-llama/Meta-Llama-3-8B-Instruct')
        model = AutoModelForCausalLM.from_pretrained(
            'meta-llama/Meta-Llama-3-8B-Instruct',
            torch_dtype=torch.bfloat16
        )
        
        for idx in tqdm(range(len(dataset))):
            code=remove_comments(dataset[idx]['input'], False)
            generated_summary=dataset[idx]['hallucinated_summary']
            if info=='info':
                input_information=information_prompt(idx, dataset, api_infos, args.model)
                score=llm_judge_others(model, tokenizer, generated_summary, input_information+code,  0.1, 0.9, 32)
            else:
                score=llm_judge_others(model, tokenizer, generated_summary, code,  0.1, 0.9, 32)
            scores.append(score)
            #overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            overall_majority_label.append(dataset[idx]['final_majority_label']) # 0.25
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
            
    elif metric == 'llm_judge_codellama_7b':

        tokenizer = AutoTokenizer.from_pretrained('meta-llama/CodeLlama-7b-Instruct-hf')
        model = AutoModelForCausalLM.from_pretrained(
            'meta-llama/Meta-Llama-3-8B-Instruct',
            torch_dtype=torch.bfloat16
        )
        
        for idx in tqdm(range(len(dataset))):
            code=remove_comments(dataset[idx]['input'], False)
            generated_summary=dataset[idx]['hallucinated_summary']
            if info=='info':
                input_information=information_prompt(idx, dataset, api_infos, args.model)
                score=llm_judge_others(model, tokenizer, generated_summary, input_information+code,  0.1, 0.9, 32)
            else:
                score=llm_judge_others(model, tokenizer, generated_summary, code,  0.1, 0.9, 32)
            scores.append(score)
            #overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            overall_majority_label.append(dataset[idx]['final_majority_label']) # 0.25
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
            
    elif metric == 'llm_judge_llama2_13b':
        pipeline = transformers.pipeline(
            "text-generation",
            model='meta-llama/Llama-2-13b-chat-hf',
            model_kwargs={"torch_dtype": torch.bfloat16},
            device_map="auto",
        )
        for idx in tqdm(range(len(dataset))):
            code=remove_comments(dataset[idx]['input'], False)
            generated_summary=dataset[idx]['hallucinated_summary']
            if info=='info':
                input_information=information_prompt(idx, dataset, api_infos, args.model)
                score=llm_judge_llama(pipeline, generated_summary, input_information+code,  0.1, 0.9, 8)
            else:
                score=llm_judge_llama(pipeline, generated_summary, code,  0.1, 0.9, 8)
            scores.append(score)
            #overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            overall_majority_label.append(dataset[idx]['final_majority_label']) # 0.25
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
            
    elif metric == 'llm_judge_llama2_7b':
        pipeline = transformers.pipeline(
            "text-generation",
            model='meta-llama/Llama-2-7b-chat-hf',
            model_kwargs={"torch_dtype": torch.bfloat16},
            device_map="auto",
        )
        for idx in tqdm(range(len(dataset))):
            code=remove_comments(dataset[idx]['input'], False)
            generated_summary=dataset[idx]['hallucinated_summary']
            if info=='info':
                input_information=information_prompt(idx, dataset, api_infos, args.model)
                score=llm_judge_llama(pipeline, generated_summary, input_information+code,  0.1, 0.9, 32)
            else:
                score=llm_judge_llama(pipeline, generated_summary, code,  0.1, 0.9, 32)
            scores.append(score)
            #overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            overall_majority_label.append(dataset[idx]['final_majority_label']) # 0.25
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
    elif metric == 'llm_judge_gemma_7B':
        tokenizer = AutoTokenizer.from_pretrained('google/gemma-7b-it')
        model = AutoModelForCausalLM.from_pretrained(
            'google/gemma-7b-it',
            torch_dtype=torch.bfloat16
        )
        
        for idx in tqdm(range(len(dataset))):
            code=remove_comments(dataset[idx]['input'], False)
            generated_summary=dataset[idx]['hallucinated_summary']
            if info=='info':
                input_information=information_prompt(idx, dataset, api_infos, args.model)
                score=llm_judge_others(model, tokenizer, generated_summary, input_information+code,  0.1, 0.9, 32)
            else:
                score=llm_judge_others(model, tokenizer, generated_summary, code,  0.1, 0.9, 32)
            scores.append(score)
            #overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            overall_majority_label.append(dataset[idx]['final_majority_label']) # 0.25
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
            
        
    elif metric == 'llm_judge_qwen_7B':
        tokenizer = AutoTokenizer.from_pretrained('Qwen/Qwen2-7B-Instruct')
        model = AutoModelForCausalLM.from_pretrained(
            'Qwen/Qwen2-7B-Instruct',
            torch_dtype=torch.bfloat16
        )
        
        for idx in tqdm(range(len(dataset))):
            code=remove_comments(dataset[idx]['input'], False)
            generated_summary=dataset[idx]['hallucinated_summary']
            if info=='info':
                input_information=information_prompt(idx, dataset, api_infos, args.model)
                score=llm_judge_others(model, tokenizer, generated_summary, input_information+code,  0.1, 0.9, 32)
            else:
                score=llm_judge_others(model, tokenizer, generated_summary, code,  0.1, 0.9, 32)
            scores.append(score)
            #overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            overall_majority_label.append(dataset[idx]['final_majority_label']) # 0.25
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
            
    elif metric == 'llm_judge_mistral':
        tokenizer = AutoTokenizer.from_pretrained('mistralai/Mistral-7B-Instruct-v0.3')
        model = AutoModelForCausalLM.from_pretrained(
            'mistralai/Mistral-7B-Instruct-v0.3',
            torch_dtype=torch.bfloat16
        )
        
        for idx in tqdm(range(len(dataset))):
            code=remove_comments(dataset[idx]['input'], False)
            generated_summary=dataset[idx]['hallucinated_summary']
            if info=='info':
                input_information=information_prompt(idx, dataset, api_infos, args.model)
                score=llm_judge_others(model, tokenizer, generated_summary, input_information+code,  0.1, 0.9, 32)
            else:
                score=llm_judge_others(model, tokenizer, generated_summary, code,  0.1, 0.9, 32)
            scores.append(score)
            #overall_majority_label.append(int(dataset[idx]['overall_majority_label']))
            overall_majority_label.append(dataset[idx]['final_majority_label']) # 0.25
            
            json_data.append({
                'idx': idx,
                'score': score,
                'majority_labels': int(dataset[idx]['overall_majority_label'])
            })
    
    
    end_time=time.time()-start_time
    print(f'Time taken for {args.metric} evaluation: {end_time:.2f} seconds')
    print(f'{metric} score: {np.mean(scores)}')
    
    # Correlation calculation
    
    pearson_corr1, pearson_p_val1 = stats.pearsonr(scores, overall_majority_label)
    print(f'[total_score] Pearson correlation: {pearson_corr1}, p-value: {pearson_p_val1}')
          
    spearman_corr1, spearman_p_val1 = stats.spearmanr(scores, overall_majority_label)
    print(f'[total_score] Spearman correlation: {spearman_corr1}, p-value: {spearman_p_val1}')
    
    kendall_corr1, kendall_p_val1 = stats.kendalltau(scores, overall_majority_label)
    print(f'[total_score] Kendall correlation: {kendall_corr1}, p-value: {kendall_p_val1}')
    
    print('------------')
        
    with open(std_output_path1, 'w') as f:
        f.write(f'Time taken for {metric} evaluation: {end_time:.2f} seconds\n')
        f.write(f'score: {np.mean(scores)}\n') 
        f.write(f'[total_score] Pearson correlation: {pearson_corr1}, p-value: {pearson_p_val1}\n')
        f.write(f'[total_score] Spearman correlation: {spearman_corr1}, p-value: {spearman_p_val1}\n')
        f.write(f'[total_score] Kendall correlation: {kendall_corr1}, p-value: {kendall_p_val1}\n')
        
        
    with open(std_output_path2, 'w') as f:
        for data in json_data:
            f.write( json.dumps(data, ensure_ascii=False) + "\n" )
            
    return 


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--model', required=False, type=str, help='Code LMs, incl. codegen, codegen25, santacoder, starcoder, codellama, gpt35, gpt4')
    parser.add_argument('--metric', required=True, type=str, help='rouge1, rouge2, rougeL, bleu, bertscore, meteor, sentbert_cosine, sentbert_euclidean, side')
    parser.add_argument('--dataset', required=True, type=str, help='dataset')
    parser.add_argument('--info', required=False, type=str, help='info,not_info')
    parser.add_argument('--file', required=True, type=str, help='information included json file')
    parser.add_argument('--api', required=True, type=str, help='api documentation path') 
    args = parser.parse_args()

    DS_FILE = os.path.join(DS_BASE_DIR, args.file)

    with open(DS_FILE, 'r') as f: # meta data
        dataset = [json.loads(line) for line in f.readlines()]
    
    #dataset=dataset[:5]
    
    print(f'There are {len(dataset)} test samples.')
    
    # API documentation num
    with open(os.path.join(DS_BASE_DIR, args.api), 'r') as f: # meta data
        api_infos=json.load(f)
    
    saved_path = f'/baseline/{args.dataset}/{args.info}/'
    if not os.path.exists(saved_path):
        os.makedirs(saved_path)
        
    #std_output_path = os.path.join(saved_path, f'log_{args.metric}.txt')
    std_output_path1 = os.path.join(saved_path, f'log_{args.metric}.txt') # score, weighted score
    std_output_path2 = os.path.join(saved_path, f'output_{args.metric}.jsonl') # segment 별 case labels
        
    ## Evaluation
    if args.metric in ['rouge1', 'rouge2', 'rougeL', 'bleu', 'bertscore', 'meteor', 'sentbert_cosine', 'sentbert_euclidean']:
        result=reference_based_evaluation(dataset, args.metric, std_output_path1, std_output_path2)
        
    elif args.metric in ['llm_judge_mistral','llm_judge_qwen_7B', 'llm_judge_gemma_7B','side', 'llm_judge_gpt_4.1_mini', 'llm_judge_gpt_4o', 'llm_judge_llama3_8B_instruct', 'llm_judge_llama2_13b', 'llm_judge_codellama_13b', 'llm_judge_codellama_7b', 'llm_judge_llama2_7b']:
        result=reference_free_evaluation(dataset, args.metric, args.info, std_output_path1, std_output_path2)
    
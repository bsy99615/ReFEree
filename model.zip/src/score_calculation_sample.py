import random
from tqdm import tqdm
import json
import time
import scipy.stats as stats
from torch.utils.data import DataLoader
from transformers import DataCollatorWithPadding
import pandas as pd
import numpy as np
import torch
from datasets import Dataset
from collections import defaultdict

from generator import Generator as promptGenerator
from argparse import ArgumentParser
from prompt import *
from utils import *
from models_gpu import *

os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"


def information_prompt(idx, dataset, api_doc):
    fpath = os.path.join(DS_REPO_DIR, dataset[idx]['fpath'])  # file path 
    graph_dir=os.path.join(DS_GRAPH_DIR, dataset[idx]['fpath'].split('/')[0]) # graph path

    generator = promptGenerator(DS_REPO_DIR, graph_dir)
    generator.set_pyfile(dataset[idx]['pkg'], fpath)
    fpath = generator._get_module_name(fpath)
    
    prompts={}
    for k,v in dataset[idx]['related_information'].items():
        if v['info_type'] == 'cross':
            for infos in v['info']:
                if infos[1]=='': continue # .py 전체를 가져오는건 너무 정보가 많기 때문에 skip
                else:
                    if generator.get_info_prompt([infos]) !=[]:
                        prompt='# '+infos[1]+' #\n'+generator.get_info_prompt([infos])[0]
                        if infos[1] in prompts: continue
                        else:
                            prompts[infos[1]]=prompt
        elif v['info_type'] == 'internal':
            for infos in v['info']:
                if generator.get_info_prompt([infos]) !=[]:
                    prompt='# '+infos[1]+' #\n'+generator.get_info_prompt([infos])[0]
                    if infos[1] in prompts: continue
                    else:
                        prompts[infos[1]]=prompt
        elif v['info_type'] == 'external':
            for infos in v['info']:
                if infos[1] in api_doc:
                    prompt='# '+infos[1]+' #\n'+api_doc[infos[1]]
                    if infos[1] in prompts: continue
                    else:
                        prompts[infos[1]]=prompt            
    information_prompt=''
    # if len(prompts) == 0:
    #     information_prompt='No related information.'
    for k,v in prompts.items():
        information_prompt+=v+'\n'
                             
    return information_prompt


def information_selected_prompt(idx, dataset, api_doc, select):

    #print(select)

    fpath = os.path.join(DS_REPO_DIR, dataset[idx]['fpath'])  # file path 
    graph_dir=os.path.join(DS_GRAPH_DIR, dataset[idx]['fpath'].split('/')[0]) # graph path

    generator = promptGenerator(DS_REPO_DIR, graph_dir)
    generator.set_pyfile(dataset[idx]['pkg'], fpath)
    fpath = generator._get_module_name(fpath)
    
    prompts={}
    for k,v in dataset[idx]['related_information'].items():
        if (v['info_type'] == 'cross') and ('cross' in select):
            for infos in v['info']:
                if infos[1]=='': continue # .py 전체를 가져오는건 너무 정보가 많기 때문에 skip
                else:
                    if generator.get_info_prompt([infos]) !=[]:
                        prompt='# '+infos[1]+' #\n'+generator.get_info_prompt([infos])[0]
                        if infos[1] in prompts: continue
                        else:
                            prompts[infos[1]]=prompt
        elif (v['info_type'] == 'internal') and ('internal' in select):
            for infos in v['info']:
                if generator.get_info_prompt([infos]) !=[]:
                    prompt='# '+infos[1]+' #\n'+generator.get_info_prompt([infos])[0]
                    if infos[1] in prompts: continue
                    else:
                        prompts[infos[1]]=prompt
        elif (v['info_type'] == 'external') and ('external' in select):
            for infos in v['info']:
                if infos[1] in api_doc:
                    prompt='# '+infos[1]+' #\n'+api_doc[infos[1]]
                    if infos[1] in prompts: continue
                    else:
                        prompts[infos[1]]=prompt            
    information_prompt=''
    if len(prompts) == 0:
        information_prompt='No related context.'
    for k,v in prompts.items():
        information_prompt+=v+'\n'
                             
    return information_prompt


def gpu_inference(model, tokenizer, dataloader, max_new_tokens, temperature, top_p, top_k):
    output_sequences = []
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    
    for batch in tqdm(dataloader, desc='inference',mininterval=0.01):
        batch = {k: v.to(device) for k, v in batch.items()}
        with torch.no_grad():
            generated_tokens = model.generate(
                **batch, 
                do_sample=True,
                max_new_tokens=max_new_tokens, 
                pad_token_id=tokenizer.eos_token_id, 
                eos_token_id=tokenizer.eos_token_id,
                temperature=temperature, 
                top_p=top_p,
                top_k=top_k)
            
            generated_tokens = torch.nn.utils.rnn.pad_sequence(
                [torch.tensor(t).to(device) for t in generated_tokens],
                batch_first=True,
                padding_value=tokenizer.pad_token_id
            )
            generated_tokens = generated_tokens.cpu().tolist()

            outputs = [tokenizer.decode(ids, skip_special_tokens=True) for ids in generated_tokens]
            output_sequences.extend(outputs)
            
    return output_sequences


@retry(tries=5, delay=2, backoff=2, max_delay=60)
def call_gpt_with_retry(model_name, message_content, max_tokens, temperature, top_p):
    """
    재시도 로직이 적용된 개별 API 호출 함수
    RateLimitError, APIError 등 다양한 예외 발생 시 자동으로 재시도합니다.
    """
    openai.api_key=chatgpt_api_key
    try:
        response = openai.ChatCompletion.create(
            model=model_name,
            messages=[{"role": "user", "content": message_content}],
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            request_timeout=60  # 2. 타임아웃을 60초로 설정
        )
        return response["choices"][0]["message"]["content"].strip()
    except Exception as e:
        print(f"An error occurred: {e}. Retrying...")
        raise # @retry가 예외를 감지하고 재시도하도록 다시 예외를 발생시킴


def API_inference(model, input_dataset, max_new_tokens, temperature, top_p):
    # MODEL_CARD는 모델 이름을 담은 딕셔너리라고 가정합니다. 예: {"gpt-4": "gpt-4-turbo"}
    model_name=MODEL_CARD[model]
    
    output_sequences = []
    for i in tqdm(range(len(input_dataset))):
        # 개별적으로 재시도 함수를 호출
        output_text = call_gpt_with_retry(
            model_name=model_name,
            message_content=input_dataset[i],
            max_tokens=max_new_tokens,
            temperature=temperature,
            top_p=top_p
        )
        
        output_sequences.append(output_text)
        
        # 3. 속도 제한을 피하기 위한 최소한의 지연 (선택 사항이지만 권장)
        time.sleep(0.1) 
            
    return output_sequences


def get_llm_input_inference(dataset, api_infos, ver, prompt_ver, shot, case, select):
    llm_input=[]
    DEMONSTRATION=DEMON[case]
    
    for idx in tqdm(range(len(dataset))):
        if shot == 'zeroshot':
            input_prompt=OURS[prompt_ver]+USER_PROMPT
        elif shot == 'fewshot':
            input_prompt=OURS[prompt_ver]+DEMONSTRATION+USER_PROMPT

        code=remove_comments(dataset[idx]['input'])
        lines = code.splitlines()
        non_empty_lines = [line for line in lines if line.strip()]
        code="\n".join(non_empty_lines)
        
        if ver == 'code_all_summ_seg':
            # summary segment
            summary_segments=dataset[idx]['segmented_hallucinated_summary']
            
            input_prompt=input_prompt.replace('{case}', case)
            input_prompt=input_prompt.replace('{explanation}', CASE[case])
            input_prompt=input_prompt.replace('{x}', code)
            input_prompt=input_prompt.replace('{text}', summary_segments)
        
        elif ver == 'info_code_all_summ_seg':
            # summary segment
            summary_segments=dataset[idx]['descriptions']
            input_information=information_selected_prompt(idx, dataset, api_infos, select)
            #input_information=dataset[idx]['input_information']

            input_x=f"(Related Context)\n{input_information}\n(Input Code)\n{code}"
            
            input_prompt=input_prompt.replace('{case}', case)
            input_prompt=input_prompt.replace('{explanation}', CASE[case])
            input_prompt=input_prompt.replace('{x}', input_x)
            input_prompt=input_prompt.replace('{text}', summary_segments)

        elif ver == 'code_all_summ_all':
            # summary segment
            summary=dataset[idx]['hallucinated_summary']
            
            input_prompt=input_prompt.replace('{case}', case)
            input_prompt=input_prompt.replace('{explanation}', CASE[case])
            input_prompt=input_prompt.replace('{x}', code)
            input_prompt=input_prompt.replace('{text}', summary)

        elif ver == 'info_code_all_summ_all':
            # summary segment
            summary=dataset[idx]['hallucinated_summary']
            #input_information=information_prompt(idx, dataset, api_infos)
            input_information=dataset[idx]['input_information']
            
            input_prompt=input_prompt.replace('{case}', case)
            input_prompt=input_prompt.replace('{explanation}', CASE[case])
            input_prompt=input_prompt.replace('{x}', input_information+code)
            input_prompt=input_prompt.replace('{text}', summary)
            
        print('*****llm input*****')
        print(input_prompt)
        llm_input.append(input_prompt)
    
    return llm_input
    

########
 
if __name__ == '__main__':

    parser = ArgumentParser()
    parser.add_argument('--model', required=True, type=str) # evaluator
    parser.add_argument('--ver', required=True, type=str, help='code_all_summ_seg, code_seg_summ_seg, info_code_all_summ_seg, info_code_seg_summ_seg')
    parser.add_argument('--prompt_ver', required=True, type=str, help='ver2')
    parser.add_argument('--shot', required=True, type=str, help='zeroshot, fewshot')
    parser.add_argument('--dataset', required=False, type=str, default='deveval')
    parser.add_argument('--file', required=True, type=str, help='information included json file')
    parser.add_argument('--api', required=False, type=str, default='api_documentation') 
    parser.add_argument('--select', required=True, type=str, help='information included json file')
    parser.add_argument('--seed', required=True, type=int, help='seed')
    parser.add_argument('--batch', required=False, type=int, help='1')
    
    args = parser.parse_args()
    
    seed = args.seed
    deterministic = True

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        
    # save path
    saved_path = f'../../result/ours/{args.ver}/{args.select}'
    if not os.path.exists(saved_path):
        os.makedirs(saved_path)
    
    std_output_path1 = os.path.join(saved_path, f'log_{args.model}_{args.prompt_ver}_{args.shot}_{args.seed}_sample.txt') # score, weighted score
    std_output_path2 = os.path.join(saved_path, f'output_{args.model}_{args.prompt_ver}_{args.shot}_{args.seed}_sample.jsonl') # segment 별 case labels
        
    # API documentation loading
    with open(f'../../dataset/{args.api}.json', 'r') as f: # meta data
        api_infos=json.load(f)
        
    # dataset loading
    with open(os.path.join(DS_BASE_DIR, args.file), 'r') as f: # meta data
        dataset = [json.loads(line) for line in f.readlines()]
    
    #dataset=dataset[:40]
     
    idx=0
    if "summ_all" in args.ver:
        re_dataset=[]
        for i in range(len(dataset)):
            if dataset[i]['idx']==idx:
                re_dataset.append(dataset[i])
                idx+=1
                continue 
        dataset=re_dataset
        reference_labels = [item['final_label'] for item in re_dataset]
    else:
        reference_labels = [item['final_label'] for item in dataset]
        
    # reference_labels=reference_labels[:1]    
    # model loading / dataset loading
    cases=[]
    cases_outputs=[]
    if "gpt" in args.model:
        start_time=time.time()
        for case in CASE:
            input_dataset=get_llm_input_inference(dataset, api_infos, args.ver, args.prompt_ver, args.shot, case, args.select)
            outputs=API_inference(args.model, input_dataset, 16, 0.1, 0.9)
            
            scores=[]
            for i in range(len(outputs)):
                if '### SCORE (score only):' in outputs[i]:
                    outputs[i]=outputs[i].split('SCORE (score only):')[-1]
                if '\n\n' in outputs[i]: outputs[i]=outputs[i].split('\n\n')[0]
                    
                if '1' in outputs[i]: scores.append(1)
                elif '0' in outputs[i]: scores.append(0)
                else: 
                    print(outputs[i])
                    scores.append(-1)
                            
            cases.append(scores)
            cases_outputs.append(outputs)
    else:
        model, tokenizer=llm_loading_gpu(args.model)
        start_time=time.time()
        for case in CASE:
            input_dataset=get_llm_input_inference(dataset, api_infos, args.ver, args.prompt_ver , args.shot, case, args.select)
            input_csv = pd.DataFrame({'llm_input': input_dataset})
            augment_dataset = Dataset.from_pandas(input_csv)
            max_len = max([len(tokenizer(text).input_ids) for text in augment_dataset['llm_input']])

            def train_preprocess_function(examples):
                return tokenizer(
                    examples['llm_input'],
                    padding="max_length",
                    truncation=True,
                    max_length=max_len
                )

            processed_dataset = augment_dataset.map(
                train_preprocess_function,
                batched=True,
                remove_columns=augment_dataset.column_names,
                load_from_cache_file=True
            )

            data_collator = DataCollatorWithPadding(tokenizer=tokenizer, return_tensors="pt")
            eval_dataloader = DataLoader(processed_dataset, collate_fn=data_collator, batch_size=args.batch)
            
            outputs=gpu_inference(model, tokenizer, eval_dataloader, 16, 0.1, 0.9, 50)
            
            scores=[]
            for i in range(len(outputs)):
                #print(outputs[i])
                if '### SCORE (score only):' in outputs[i]:
                    outputs[i]=outputs[i].split('SCORE (score only):')[-1]
                if '\n\n' in outputs[i]: outputs[i]=outputs[i].split('\n\n')[0]
                
                if '1' in outputs[i]: scores.append(1)
                elif '0' in outputs[i]: scores.append(0)
                else: 
                    print(outputs[i])
                    scores.append(-1)
                            
            cases.append(scores)
            cases_outputs.append(outputs)
        
    cases=np.array(cases)
    print(cases)
    
    end_time=time.time()-start_time
    print(f'Time taken for {args.ver} evaluation: {end_time:.2f} seconds')
    
    # segment score
    segment_level_score= cases.sum(axis=0)
    
    print(segment_level_score)
    
    # tranpose : segment len x cases
    tranpose_scores= cases.T
    
    #print(tranpose_scores)
    
    #print(cases_outputs)
    
    json_data=[]
    for i in range(len(dataset)):
        json_data.append({
            'idx': dataset[i]['idx'],
            'seg_idx': dataset[i]['seg_idx'],
            'case1_output': cases_outputs[0][i],
            'case2_output': cases_outputs[1][i],
            'case3_output': cases_outputs[2][i],            
            'case4_output': cases_outputs[3][i],            
            'prediction_score_by_cases': tranpose_scores[i].tolist(),
            'final_label': dataset[i]['final_label']
        })
    
    grouped_scores = defaultdict(list)
    final_labels={}
    for item in json_data:
        idx = item['idx']
        scores = item['prediction_score_by_cases']

        grouped_scores[idx].append(scores)
        if idx not in final_labels:
            final_labels[idx] = item['final_label']
        
    result_arrays = {}
    for idx, scores_list in grouped_scores.items():
        result_arrays[idx] = np.array(scores_list)
        
    #print(result_arrays)
    
    # final score list
    prediction_scores=[]
    for k,v in result_arrays.items():
        score=(v == 1).sum() / v.size
        prediction_scores.append(score)
    
    reference_scores=list(final_labels.values())

    print(f'{args.ver} [reference_scores] score:{np.mean(reference_scores)}')
    print(f'{args.ver} [prediction_scores] score:{np.mean(prediction_scores)}')
    
    # Correlation calculation
    pearson_corr1, pearson_p_val1 = stats.pearsonr(reference_scores, prediction_scores)
    print(f'Pearson correlation: {pearson_corr1}, p-value: {pearson_p_val1}')
          
    spearman_corr1, spearman_p_val1 = stats.spearmanr(reference_scores, prediction_scores)
    print(f'Spearman correlation: {spearman_corr1}, p-value: {spearman_p_val1}')
    
    kendall_corr1, kendall_p_val1 = stats.kendalltau(reference_scores, prediction_scores)
    print(f'Kendall correlation: {kendall_corr1}, p-value: {kendall_p_val1}')
    
    print('------------')
        
    with open(std_output_path1, 'w') as f:
        f.write(f'Time taken for {args.model} {args.ver} evaluation: {end_time:.2f} seconds\n')
        f.write(f'score: {np.mean(prediction_scores)}\n')
        f.write('----')
        f.write(f'Pearson correlation: {pearson_corr1}, p-value: {pearson_p_val1}\n')
        f.write(f'Spearman correlation: {spearman_corr1}, p-value: {spearman_p_val1}\n')
        f.write(f'Kendall correlation: {kendall_corr1}, p-value: {kendall_p_val1}\n')
    
    with open(std_output_path2, 'w') as f:
        for data in json_data:
            f.write( json.dumps(data, ensure_ascii=False) + "\n" )
import os
import json

from utils import MAX_HOP, ONLY_DEF, ENABLE_DOCSTRING

from extract_dataflow import PythonParser
from node_prompt import projectSearcher

class Generator(object):
    def __init__(self, proj_dir, info_dir):
        self.parser = PythonParser()
        self.proj_dir = os.path.abspath(proj_dir) # repo directory
        self.info_dir = os.path.abspath(info_dir) # graph directory

        self.searcher = projectSearcher()
        #self.tokenizer = ModelTokenizer(model)

        self.project = None
        self.proj_info = None
    

    def _set_project(self, project):
        if project == self.project:
            return

        info_file = os.path.join(self.info_dir, f'{project}.json')
        if not os.path.isfile(info_file):
            print(f'Unknown package {project} in {self.info_dir}')
            return
        
        self.project = project
        with open(info_file, 'r') as f:
            self.proj_info = json.load(f)
    
    def set_pyfile(self, project, fpath):
        self._set_project(project)

        # remove current file 
        if fpath in self.proj_info:
            proj_info = {k:v for k,v in self.proj_info.items() if k != fpath}
        else:
            proj_info = self.proj_info
        
        dir_path = os.path.join(self.proj_dir, project)
        
        if os.path.isdir(dir_path):
            content = list(os.listdir(dir_path))
            if len(content) == 1:
                dir_path = os.path.join(dir_path, content[0])
        
        self.searcher.set_proj(dir_path, proj_info)
    

    def _get_module_name(self, fpath):
        if fpath.endswith('.py'):
            fpath = fpath[:-3]
            if fpath.endswith('__init__'):
                fpath = fpath[:-8]

        fpath = fpath.rstrip(os.sep)
        return fpath[len(self.searcher.proj_dir):].replace(os.sep, '.')


    def get_suffix(self, fpath):
        return self.searcher.get_path_comment(fpath)
    

    def sort_by_lineno(self, src_list, reverse=True):
        '''
        src_list: [(anything, ..., lineno)]
        Return: sorted list without lineno
        '''
        sorted_list = sorted(src_list, key=lambda x:x[-1], reverse=reverse)
        return [x[:-1] for x in sorted_list]

    def get_cross_file_nodes(self, fpath, imported_info):
        # imported_info= [(None, None), ('falcon', 'errors'), ('falcon', 'errors.HTTPInvalidHeader')]
        node_list = []
        for item in imported_info:
            if (item[0] is None) & (item[1] is None):
                continue
            else:
                find_info = self.searcher.is_local_import(fpath, item) 
                if find_info is not None:
                    if find_info[1] is None:
                        find_info = (find_info[0], '')
                    else:
                        find_info = tuple(find_info)
                    
                    if find_info not in node_list:
                        node_list.append(find_info)
        
        return node_list

    def get_info_prompt(self, node_list):
        #print(node_list)
        return self.searcher.get_prompt(node_list, MAX_HOP, ONLY_DEF, ENABLE_DOCSTRING)
from argparse import ArgumentParser
import scipy.stats as stats
from tqdm import tqdm
import time
import random
import torch
import json
import numpy as np
from sentence_transformers import SentenceTransformer
from torch.utils.data import DataLoader
from transformers import DataCollatorWithPadding
from datasets import Dataset
from collections import defaultdict
import pandas as pd
from utils import *
from prompt import *
from models_gpu import *

def get_llm_input_inference(dataset, ver):
    llm_input=[]
    if '_info' in ver:
        ver=ver.split('_info')[0].strip()
        tag=1
    else:
        tag=0
    
    for idx in tqdm(range(len(dataset))):
        input_prompt=LaaJ[ver]

        code=remove_comments(dataset[idx]['input'])
        lines = code.splitlines()
        non_empty_lines = [line for line in lines if line.strip()]
        code="\n".join(non_empty_lines)
        
        info=dataset[idx]['input_information']        
        summary=dataset[idx]['hallucinated_summary']
        
        if tag==1:
            input_prompt=input_prompt.replace('{x}', info+code)
            input_prompt=input_prompt.replace('{text}', summary)
        elif tag==0:
            input_prompt=input_prompt.replace('{x}', code)
            input_prompt=input_prompt.replace('{text}', summary)
            
        # print('*****llm input*****')
        # print(input_prompt)
        llm_input.append(input_prompt)
    
    return llm_input

def gpu_inference(model, tokenizer, dataloader, max_new_tokens, temperature, top_p, top_k):
    output_sequences = []
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    
    for batch in tqdm(dataloader, desc='inference',mininterval=0.01):
        batch = {k: v.to(device) for k, v in batch.items()}
        with torch.no_grad():
            generated_tokens = model.generate(
                **batch, 
                do_sample=True,
                max_new_tokens=max_new_tokens, 
                pad_token_id=tokenizer.eos_token_id, 
                eos_token_id=tokenizer.eos_token_id,
                temperature=temperature, 
                top_p=top_p,
                top_k=top_k)
            
            generated_tokens = torch.nn.utils.rnn.pad_sequence(
                [torch.tensor(t).to(device) for t in generated_tokens],
                batch_first=True,
                padding_value=tokenizer.pad_token_id
            )
            generated_tokens = generated_tokens.cpu().tolist()

            outputs = [tokenizer.decode(ids, skip_special_tokens=True) for ids in generated_tokens]
            output_sequences.extend(outputs)
            
    return output_sequences

@retry(Exception, tries=5, delay=1, backoff=2, max_delay=120)
def API_inference(model, input_dataset, max_new_tokens, temperature, top_p):
    openai.api_key=chatgpt_api_key
    
    output_sequences = []
    for i in tqdm(range(len(input_dataset))):
        response = openai.ChatCompletion.create(
            model=MODEL_CARD[model],
            temperature = temperature, 
            top_p=top_p, 
            max_tokens=max_new_tokens,
            messages=[
                {"role": "user",  
                "content": input_dataset[i]}
            ]
        )
        output_text = response["choices"][0]["message"]["content"].strip()
        output_sequences.append(output_text)
        
    return output_sequences


def reference_based_evaluation(dataset, ver):
    results=[]    
    start_time=time.time()

    if ver == 'rouge1':
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_rouge(gold_summary, generated_summary, 'rouge1')
            results.append(score)
        
    elif ver == 'rouge2':
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']            
            score=cal_rouge(gold_summary, generated_summary, 'rouge2')
            results.append(score)
        
    elif ver == 'rougeL':
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']            
            score=cal_rouge(gold_summary, generated_summary, 'rougeL')
            results.append(score)
        
    elif ver == 'bleu':
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_bleu(gold_summary, generated_summary)
            results.append(score)
            
    elif ver == 'bertscore':
        bert_scorer = evaluate.load("bertscore")
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_bertscore(bert_scorer, gold_summary, generated_summary)
            results.append(score)

    elif ver == 'meteor':
        meteor_scorer = evaluate.load('meteor')
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_meteor(meteor_scorer, gold_summary, generated_summary)
            results.append(score)
            
    elif ver == 'sentbert_cosine':
        sentbert_model = SentenceTransformer('all-MiniLM-L6-v2')
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_sentbert_cosine(sentbert_model, gold_summary, generated_summary)
            results.append(score)
            
    elif ver == 'sentbert_euclidean':
        sentbert_model = SentenceTransformer('all-MiniLM-L6-v2')
        for idx in tqdm(range(len(dataset))):
            gold_summary=dataset[idx]['descriptions']['Functionality']
            generated_summary=dataset[idx]['hallucinated_summary']
            score=cal_sentbert_euclidean(sentbert_model, gold_summary, generated_summary)
            results.append(score)
            
    end_time=time.time()-start_time
            
    return results, end_time

def side_evaluation(dataset, ver):
    results=[]
    start_time=time.time()
    
    for idx in tqdm(range(len(dataset))):
        code=remove_comments(dataset[idx]['input'])
        lines = code.splitlines()
        non_empty_lines = [line for line in lines if line.strip()]
        code="\n".join(non_empty_lines)
        
        generated_summary=dataset[idx]['hallucinated_summary']
        score=side(generated_summary, code)
        results.append(score)
        
    end_time=time.time()-start_time

    return results, end_time


def llm_as_a_judge(dataset, ver, model):
    results=[]
    # input
    input_dataset=get_llm_input_inference(dataset, ver)
    
    if 'gpt' in model:
        start_time=time.time()
        outputs=API_inference(model, input_dataset, 16, 0.1, 0.9)
        end_time=time.time()-start_time
        
        print(outputs[:10])
        for i in range(len(outputs)):
            if '\n\n' in outputs[i]: outputs[i]=outputs[i].split('\n\n')[0]
            
            if '1' in outputs[i]: results.append(1)
            elif '2' in outputs[i]: results.append(2)
            elif '3' in outputs[i]: results.append(3)
            elif '4' in outputs[i]: results.append(4)
            elif '5' in outputs[i]: results.append(5)
            else:
                print(outputs[i]) 
                results.append(-1)
   
    else:
        model, tokenizer=llm_loading_gpu(args.model)
        input_csv = pd.DataFrame({'llm_input': input_dataset})
        augment_dataset = Dataset.from_pandas(input_csv)
        max_len = max([len(tokenizer(text).input_ids) for text in augment_dataset['llm_input']])

        def train_preprocess_function(examples):
            return tokenizer(
                examples['llm_input'],
                padding="max_length",
                truncation=True,
                max_length=max_len
            )

        processed_dataset = augment_dataset.map(
            train_preprocess_function,
            batched=True,
            remove_columns=augment_dataset.column_names,
            load_from_cache_file=True
        )
        
        data_collator = DataCollatorWithPadding(tokenizer=tokenizer, return_tensors="pt")
        eval_dataloader = DataLoader(processed_dataset, collate_fn=data_collator, batch_size=args.batch)
        start_time=time.time()
        outputs=gpu_inference(model, tokenizer, eval_dataloader, 16, 0.1, 0.9, 50)
        end_time=time.time()-start_time

        #print(outputs)
        for i in range(len(outputs)):
            if 'SCORE (score only):' in outputs[i]:
                outputs[i]=outputs[i].split('SCORE (score only):')[-1]
            
            # if '\n' in output:
            #     output=output.split('\n')[0].strip()
            
            if '1' in outputs[i]: results.append(1)
            elif '2' in outputs[i]: results.append(2)
            elif '3' in outputs[i]: results.append(3)
            elif '4' in outputs[i]: results.append(4)
            elif '5' in outputs[i]: results.append(5)
            else: 
                print(outputs[i])
                results.append(-1)
        
    #print(results)
            
    return outputs, results, end_time


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--ver', required=True, type=str, help='rouge1, rouge2, rougeL, bleu, bertscore, meteor, sentbert_cosine, sentbert_euclidean, side')
    parser.add_argument('--model', required=False, type=str)
    parser.add_argument('--dataset', required=False, type=str, default='deveval')
    parser.add_argument('--file', required=True, type=str, help='information included json file')
    parser.add_argument('--api', required=False, type=str, default='api_documentation') 
    parser.add_argument('--seed', required=True, type=int, help='seed')
    parser.add_argument('--batch', required=False, type=int, help='1')
    args = parser.parse_args()
    
    seed = args.seed
    deterministic = True

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        
    # save path
    saved_path = f'../../result/baselines/{args.ver}/'
    if not os.path.exists(saved_path):
        os.makedirs(saved_path)
    
    # laaj1_info
    if 'laaj' in args.ver :
        std_output_path1 = os.path.join(saved_path, f'log_{args.ver}_{args.model}_{args.seed}.txt')
        std_output_path2 = os.path.join(saved_path, f'output_{args.ver}_{args.model}_{args.seed}.jsonl')
    else:
        std_output_path1 = os.path.join(saved_path, f'log_{args.ver}_{args.seed}.txt')
        std_output_path2 = os.path.join(saved_path, f'output_{args.ver}_{args.seed}.jsonl')
        
    # API documentation loading
    with open(f'../../dataset/{args.api}.json', 'r') as f: # meta data
        api_infos=json.load(f)
        
    # dataset loading
    with open(os.path.join(DS_BASE_DIR, args.file), 'r') as f: # meta data
        dataset = [json.loads(line) for line in f.readlines()]
    
    #dataset=dataset[:10]
    
    # reference label
    reference_labels = [item['final_label'] for item in dataset]
    
    # score calculation
    if args.ver in ['rouge1', 'rouge2', 'rougeL', 'bleu', 'bertscore', 'meteor', 'sentbert_cosine', 'sentbert_euclidean']:
        results, end_time = reference_based_evaluation(dataset, args.ver)
        print(f'Time taken for {args.ver} evaluation: {end_time:.2f} seconds')
        json_data=[]
        for i in range(len(dataset)):
            json_data.append({
                'idx': dataset[i]['idx'],
                'prediction_scores': results[i],
                'final_label': dataset[i]['final_label']
            })
    elif args.ver == 'side':
        results, end_time = side_evaluation(dataset, args.ver)
        print(f'Time taken for {args.ver} evaluation: {end_time:.2f} seconds')
        json_data=[]
        for i in range(len(dataset)):
            json_data.append({
                'idx': dataset[i]['idx'],
                'prediction_scores': results[i],
                'final_label': dataset[i]['final_label']
            })
            
    elif 'laaj' in args.ver:
        outputs, results, end_time = llm_as_a_judge(dataset, args.ver, args.model)
        print(f'Time taken for {args.ver}-{args.model} evaluation: {end_time:.2f} seconds')
        
        json_data=[]
        for i in range(len(dataset)):
            json_data.append({
                'idx': dataset[i]['idx'],
                'outputs': outputs[i],
                'prediction_scores': results[i],
                'final_label': dataset[i]['final_label']
            })
    
    print(f'{args.ver} [reference_scores] score:{np.mean(reference_labels)}')
    print(f'{args.ver} [prediction_scores] score:{np.mean(results)}')
    
    # Correlation calculation
    pearson_corr1, pearson_p_val1 = stats.pearsonr(reference_labels, results)
    print(f'Pearson correlation: {pearson_corr1}, p-value: {pearson_p_val1}')
          
    spearman_corr1, spearman_p_val1 = stats.spearmanr(reference_labels, results)
    print(f'Spearman correlation: {spearman_corr1}, p-value: {spearman_p_val1}')
    
    kendall_corr1, kendall_p_val1 = stats.kendalltau(reference_labels, results)
    print(f'Kendall correlation: {kendall_corr1}, p-value: {kendall_p_val1}')
    
    print('------------')
        
    with open(std_output_path1, 'w') as f:
        f.write(f'Time taken for {args.model} {args.ver} evaluation: {end_time:.2f} seconds\n')
        f.write(f'score: {np.mean(results)}\n') 
        f.write(f'Pearson correlation: {pearson_corr1}, p-value: {pearson_p_val1}\n')
        f.write(f'Spearman correlation: {spearman_corr1}, p-value: {spearman_p_val1}\n')
        f.write(f'Kendall correlation: {kendall_corr1}, p-value: {kendall_p_val1}\n')
    
    with open(std_output_path2, 'w') as f:
        for data in json_data:
            f.write( json.dumps(data, ensure_ascii=False) + "\n" )
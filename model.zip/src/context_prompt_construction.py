import random
from tqdm import tqdm
import json
import time
import scipy.stats as stats
from torch.utils.data import DataLoader
from transformers import DataCollatorWithPadding
import pandas as pd
import numpy as np
import torch
from datasets import Dataset
from collections import defaultdict

from generator import Generator as promptGenerator
from argparse import ArgumentParser
from prompt import *
from utils import *
from models_gpu import *

os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"


def information_prompt(idx, dataset, api_doc):
    fpath = os.path.join(DS_REPO_DIR, dataset[idx]['fpath'])  # file path 
    graph_dir=os.path.join(DS_GRAPH_DIR, dataset[idx]['fpath'].split('/')[0]) # graph path

    generator = promptGenerator(DS_REPO_DIR, graph_dir)
    generator.set_pyfile(dataset[idx]['pkg'], fpath)
    fpath = generator._get_module_name(fpath)
    
    prompts={}
    for k,v in dataset[idx]['related_information'].items():
        if v['info_type'] == 'cross':
            for infos in v['info']:
                if infos[1]=='': continue # .py 전체를 가져오는건 너무 정보가 많기 때문에 skip
                else:
                    if generator.get_info_prompt([infos]) !=[]:
                        prompt='# '+infos[1]+' #\n'+generator.get_info_prompt([infos])[0]
                        if infos[1] in prompts: continue
                        else:
                            prompts[infos[1]]=prompt
        elif v['info_type'] == 'internal':
            for infos in v['info']:
                if generator.get_info_prompt([infos]) !=[]:
                    prompt='# '+infos[1]+' #\n'+generator.get_info_prompt([infos])[0]
                    if infos[1] in prompts: continue
                    else:
                        prompts[infos[1]]=prompt
        elif v['info_type'] == 'external':
            for infos in v['info']:
                if infos[1] in api_doc:
                    prompt='# '+infos[1]+' #\n'+api_doc[infos[1]]
                    if infos[1] in prompts: continue
                    else:
                        prompts[infos[1]]=prompt            
    information_prompt=''
    # if len(prompts) == 0:
    #     information_prompt='No related information.'
    for k,v in prompts.items():
        information_prompt+=v+'\n'
        
                             
    return information_prompt


########
 
if __name__ == '__main__':

    parser = ArgumentParser()
    parser.add_argument('--model', required=True, type=str) # evaluator
    parser.add_argument('--ver', required=True, type=str, help='code_all_summ_seg, code_seg_summ_seg, info_code_all_summ_seg, info_code_seg_summ_seg')
    parser.add_argument('--prompt_ver', required=True, type=str, help='ver2')
    parser.add_argument('--shot', required=True, type=str, help='zeroshot, fewshot')
    parser.add_argument('--dataset', required=False, type=str, default='deveval')
    parser.add_argument('--file', required=True, type=str, help='information included json file')
    parser.add_argument('--api', required=False, type=str, default='api_documentation') 
    parser.add_argument('--seed', required=True, type=int, help='seed')
    parser.add_argument('--batch', required=False, type=int, help='1')
    
    args = parser.parse_args()
    
    seed = args.seed
    deterministic = True

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


        
    # API documentation loading
    with open(f'../../dataset/{args.api}.json', 'r') as f: # meta data
        api_infos=json.load(f)
        
    # dataset loading
    with open(os.path.join(DS_BASE_DIR, args.file), 'r') as f: # meta data
        dataset = [json.loads(line) for line in f.readlines()]
    
    
    for idx in range(len(dataset)):
        dataset[idx]['information_prompt']=information_prompt(idx, dataset, api_infos)
        
    print(dataset[0])
     
    
    with open("ReFEree/dataset/deveval/metadata_context_v2.jsonl", 'w') as f:
        for data in dataset:
            f.write( json.dumps(data, ensure_ascii=False) + "\n" )
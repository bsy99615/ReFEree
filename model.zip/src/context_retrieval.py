import os
import re
import json
from tqdm import tqdm
from argparse import ArgumentParser
from termcolor import cprint
import tokenize
import io

from generator import Generator as promptGenerator
from graph import tGraph

from utils import *


def remove_comment(code_string: str) -> str:
    result_tokens = []
    code_io = io.StringIO(code_string)
    
    is_docstring_position = True

    for token in tokenize.generate_tokens(code_io.readline):
        # 1. '#'으로 시작하는 한 줄 주석은 건너뜁니다.
        if token.type == tokenize.COMMENT:
            continue

        # 2. 독스트링을 확인하고 건너뜁니다.
        #    - 현재 위치가 독스트링이 올 수 있는 위치이고(is_docstring_position=True)
        #    - 현재 토큰 타입이 문자열(STRING)인 경우
        if is_docstring_position and token.type == tokenize.STRING:
            # 이 토큰은 독스트링이므로 결과에 추가하지 않고, 플래그를 리셋합니다.
            is_docstring_position = False
            continue
        
        # 3. 다음 토큰을 위해 플래그 상태를 업데이트합니다.
        if token.type == tokenize.INDENT:
            # 들여쓰기가 시작되면, 바로 다음은 독스트링 위치일 수 있습니다.
            is_docstring_position = True
        elif token.type not in [tokenize.DEDENT, tokenize.NL, tokenize.NEWLINE, tokenize.ENCODING]:
            # 주석, 공백, 들여쓰기/내어쓰기를 제외한 다른 의미 있는 토큰이 나타나면
            # 더 이상 독스트링이 올 수 있는 위치가 아닙니다.
            is_docstring_position = False

        # 처리된 토큰을 결과 리스트에 추가합니다.
        result_tokens.append(token)
            
    # 필터링된 토큰들을 다시 합쳐서 완전한 코드 문자열로 복원합니다.
    result_text=tokenize.untokenize(result_tokens)
    result_text=result_text.replace("\\", '')
    
    return result_text


def file_node_extraction(graph, generator, fpath):
    cross_nodes, internal_nodes, external_nodes=set(), set(), set()
    external_node_dict=dict()

    for k, v in graph.node_dict.items():
        if v.node_type=='import':
            # node type 이 import 이고, local import 정보에 없으면: cross
            if generator.searcher.is_local_import(fpath, (v.module, v.name)) is not None:
                try:
                    #print('cross:', k, v.var_name, v.node_entity)
                    cross_nodes.add(k)
                except KeyError:
                    cprint(f"KeyError in node {k}", "red")
                    continue
            else:
            # node type 이 import 이고, local import 정보에 있으면: cross
                try:
                    #print('external:', k, v.var_name, v.node_entity)
                    external_nodes.add(k)
                    node = graph.node_dict[k]
                    node_info = {
                        "module": node.module,
                        "name": node.name,
                    }
                    external_node_dict[k] = node_info
                except KeyError:
                    cprint(f"KeyError in node {k}", "red")
                    continue
        
        # import 정보가 아니고, function, class, variable 이면 internal.
        else:
            if v.node_entity in ['class_definition', 'function_definition', 'assignment', 'augmented_assignment']:
                try:
                    #print('internal:', k, v.var_name, v.node_entity)
                    internal_nodes.add(k)
                except KeyError:
                    cprint(f"KeyError in node {k}", "red")
                    continue
    
    return cross_nodes, internal_nodes, external_nodes, external_node_dict


def context_retriever(idx, dataset):

    fpath = os.path.join(DS_REPO_DIR, dataset[idx]['fpath'])  # file path 
    graph_dir=os.path.join(DS_GRAPH_DIR, dataset[idx]['fpath'].split('/')[0]) # graph path
    
    # file open and remove comments
    f = open(fpath, 'r')
    lines = f.readlines()
    fpath_content="".join(lines)
    fpath_content_after=remove_comment(fpath_content)

    generator = promptGenerator(DS_REPO_DIR, graph_dir)
    generator.set_pyfile(dataset[idx]['pkg'], fpath)
    fpath = generator._get_module_name(fpath)
    
    generator.parser.parse(fpath_content_after) # file parsing
    graph = tGraph(generator.parser.DFG) # graph construction
    
    
    # related nodes extraction
    cross_nodes, internal_nodes, external_nodes, external_node_dict = file_node_extraction(graph, generator, fpath)
    
    # input code 와 관련된 related node
    start_function_line=dataset[idx]['signature_position'][0]
    end_function_line=dataset[idx]['body_position'][1]

    # Related Nodes
    variable_nodes = graph.get_function_variables(start_function_line, end_function_line)       
    
    #cprint(remove_comment(dataset[idx]['input']), 'blue') 
    
    # Related Nodes 중에서 function, class, method 만 뽑기
    
    external_doc=[]
    context_nodes=[]
    for i in variable_nodes:
        # input related node 중에 다음에 해당하는 node type만 뽑기
        if graph.node_dict[i].node_entity in ['call', 'attribute', 'identifier', 'subscript', 'assignment', 'augmented_assignment']:
            #print(i, ":", graph.node_dict[i].var_name, ":", graph.node_dict[i].node_entity)
            context_nodes.append(i)
    

    # 각 context node 에 대해서 related context retrieve
    related_information={}
    '''
    {node: {
        var_name : var_name,
        node_entity : node_entity,
        info_type : 'cross', 'external', 'internal',
        info : info
    }}
    '''
    #print('****')
    for i in context_nodes:
                
        # 해당 node와 관련된 related node 출력
        related_nodes = graph.get_related_nodes([i], limit_assign=True, reverse=True)
        
        #Debugging
        #print('-------------------')
        #for i in related_nodes:
        #    print(i, ":", graph.node_dict[i].var_name, graph.node_dict[i].node_entity)
            
        cross_proj_nodes = set(related_nodes) & cross_nodes
        external_proj_nodes = set(related_nodes) & external_nodes

        # related node에 cross_node 정보가 있으면, 해당 node는 결국 cross information임.
        if cross_proj_nodes: 
            
            subgraph = graph.get_assign_subgraph(related_nodes, cross_proj_nodes)
            cross_imported_dict = {}
            for k, v in subgraph.module_info.items():
                for item in v:
                    # (module, name)
                    info = tuple(item[:2])
                    # pos: smaller is better (the lineno of import statements)
                    pos = (0, item[2])
                    if info not in cross_imported_dict:
                        cross_imported_dict[info] = pos
                    else:
                        cross_imported_dict[info] = min(cross_imported_dict[info], pos)
                        
            cross_imported_info = generator.sort_by_lineno([(k[0], k[1], v) for k, v in cross_imported_dict.items()])
            cross_node_list = generator.get_cross_file_nodes(fpath, cross_imported_info) # judge if module.name is imported from current project

            related_information[i]={
                                        'var_name' : graph.node_dict[i].var_name,
                                        'node_entity' : graph.node_dict[i].node_entity,
                                        'info_type' : 'cross',
                                        'info' : cross_node_list        
                                    }
            
        # External
        elif external_proj_nodes: 
            call_name=''
            for k,v in related_nodes.items():
                #print(k, ":", graph.node_dict[k].var_name, graph.node_dict[k].node_entity)
                if graph.node_dict[k].node_entity in ['call', 'subscript']:
                    call_name='.'+graph.node_dict[k].var_name.split('.')[-1]+call_name
                #print(k, ":", graph.node_dict[k].var_name, graph.node_dict[k].node_entity)
            
            external_imported_info=[]
            for n in external_proj_nodes:
                node_info = external_node_dict[n]
                if node_info["name"] == None:
                    module=str(node_info["module"])
                    if call_name != '' and call_name[0]=='.':
                        external_imported_info.append((f"import {module}", f"{module}.{call_name.split('.')[1]}"))
                    elif call_name != '' and call_name[0]!='.':
                        external_imported_info.append((f"import {module}", f"{module}.{call_name.split('.')[0]}"))
                    else:
                        external_imported_info.append((f"import {module}", f"{module}"))
                else:
                    module=str(node_info["module"])
                    name=str(node_info["name"])
                    external_imported_info.append((f"from {module} import {name}", f"{module}.{name}"))
            
            #cprint(f"external: {external_imported_info}", 'yellow')
            
            external_doc.extend(external_imported_info)
            related_information[i]={
                                        'var_name' : graph.node_dict[i].var_name,
                                        'node_entity' : graph.node_dict[i].node_entity,
                                        'info_type' : 'external',
                                        'info' : external_imported_info        
                                    }
            
        else: 
            # current file path
            path1=dataset[idx]['fpath'][len(dataset[idx]['project_path'])+1:-3]
            path1=path1.replace('/', '.')
            
            class_name=""        
            re_related_nodes={}
            for k,v in related_nodes.items():
                re_related_nodes[k]=v
                if graph.node_dict[k].node_entity == 'class_definition':
                    #re_related_nodes[k]=v
                    class_name=graph.node_dict[k].var_name
                    break
            
            #cprint(f"related nodes: {re_related_nodes}", 'yellow')
            
            internal_info=[]
            
            for k, v in re_related_nodes.items():
                if graph.node_dict[k].node_entity in ['class_definition', 'function_definition', 'assignment', 'augmented_assignment']:
                    if 'self.' in graph.node_dict[k].var_name:
                        internal_info.append((path1, graph.node_dict[k].var_name.replace('self', class_name)))
                    else:
                        internal_info.append((path1, graph.node_dict[k].var_name))
            
            if len(internal_info)!=0:
                #cprint(f"internal: {internal_info}", 'yellow')   
                related_information[i]={
                                            'var_name' : graph.node_dict[i].var_name,
                                            'node_entity' : graph.node_dict[i].node_entity,
                                            'info_type' : 'internal',
                                            'info' : list(set(internal_info))   
                                        }      

    return related_information, external_doc, generator.proj_info


if __name__ == '__main__':

    parser = ArgumentParser()
    parser.add_argument('--file', required=True, type=str, help='prompt output file')
    parser.add_argument('--api', required=False, type=str, help='api documentation path', default='api_documentation.json')
    args = parser.parse_args()

    # data loaing
    with open(DS_FILE, 'r') as f: # meta data
        dataset = [json.loads(line) for line in f.readlines()]
        
    print(f'There are {len(dataset)} samples in DevEval.')
    
    #dataset=dataset[:5]
    
    for idx in tqdm(range(len(dataset))):
        related_information, external_doc, proj_info=context_retriever(idx, dataset)
        
        print(related_information)
        
        dataset[idx]['related_information']=related_information
        dataset[idx]['dependency']['external_info']=list(set(external_doc))
    
    #save dataset
    with open(os.path.join(DS_BASE_DIR, args.file), 'w') as f:
        for item in dataset:
            json.dump(item, f)
            f.write('\n')
      
    
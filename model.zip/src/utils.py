import os
from retry import retry
import openai
import torch
import torch.nn.functional as F


chatgpt_api_key='##'
huggingface_access_token='##'


MAX_HOP = 1
ONLY_DEF = False
ENABLE_DOCSTRING = True

DS_BASE_DIR = os.path.abspath("../../dataset/deveval") #dataset path 
DS_REPO_DIR = os.path.join(DS_BASE_DIR, "Source_Code") # repository path
DS_FILE = os.path.join(DS_BASE_DIR, "metadata.jsonl") # metadata path
DS_GRAPH_DIR = os.path.join(DS_BASE_DIR, "Graph")


# functions

from rouge_score import rouge_scorer
import evaluate
from sklearn.metrics.pairwise import cosine_similarity
from scipy.spatial.distance import euclidean
from sentence_transformers import util
from transformers import AutoTokenizer, AutoModel
import ast

class DocstringRemover(ast.NodeTransformer):

    def _remove_docstring(self, node):
        if not node.body:
            return
        if isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, (ast.Str, ast.Constant)):
            node.body = node.body[1:]

    def visit_FunctionDef(self, node):
        self._remove_docstring(node)
        self.generic_visit(node)
        return node

    def visit_ClassDef(self, node):
        self._remove_docstring(node)
        self.generic_visit(node)
        return node

    def visit_Module(self, node):
        self._remove_docstring(node)
        self.generic_visit(node)
        return node

def remove_comments(code_string: str) -> str:
    try:
        tree = ast.parse(code_string)
        
        transformer = DocstringRemover()
        new_tree = transformer.visit(tree)

        return ast.unparse(new_tree)
    except Exception as e:
        #print(f"코드 처리 중 오류 발생: {e}")
        return code_string
    


# Rouge
def cal_rouge(ref, ans, type):
    scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
    # 점수 계산
    scores = scorer.score(ref, ans)
    if type == 'rouge1':
        rouge1_score = scores['rouge1'].fmeasure
        return round(rouge1_score, 4)
    elif type == 'rouge2':
        rouge2_score = scores['rouge2'].fmeasure
        return round(rouge2_score, 4)
    elif type == 'rougeL':
        rougeL_score = scores['rougeL'].fmeasure
        return round(rougeL_score, 4)
    
# Bleu
def cal_bleu(ref, ans):
    """
    ref: reference summary
    ans: generated summary
    """
    scorer = evaluate.load("bleu")
    
    # BLEU 점수 계산
    bleu_score=scorer.compute(predictions=[ans], references=[ref])["bleu"]
    
    return round(bleu_score, 4)

# Bertscore

def cal_bertscore(bert_scorer, ref, ans):
    """
    ref: reference summary
    ans: generated summary
    """
    # bert 점수 계산
    
    bertscore=bert_scorer.compute(predictions=[ans], references=[ref], model_type="distilbert-base-uncased")['f1'][0]
    
    #print(bertscore)
    
    return round(bertscore, 4)

# Meteor
def cal_meteor(meteor_scorer, ref, ans):
    """
    ref: reference summary
    ans: generated summary
    """
    #meteor_scorer = evaluate.load('meteor')
    
    # bert 점수 계산
    meteor_score=meteor_scorer.compute(predictions=[ans], references=[ref])['meteor']
    
    return round(meteor_score, 4)

# sentence-bert with cosine similarity
def cal_sentbert_cosine(sentbert_model, ref, ans):
    """
    ref: reference summary
    ans: generated summary
    """
    embeddings = sentbert_model.encode([ref, ans])
    similarity = cosine_similarity([embeddings[0]], [embeddings[1]])
    
    return round(similarity[0][0], 4)

# sentence-bert with euclidean
def cal_sentbert_euclidean(sentbert_model, ref, ans):
    """
    ref: reference summary
    ans: generated summary
    """
    embedding1 = sentbert_model.encode(ref)
    embedding2 = sentbert_model.encode(ans)
    distance = euclidean(embedding1, embedding2)
    
    return round(distance, 4)

# SIDE
SIDE_DEVICE = "cpu"
checkPointFolder = "##" #specify the path to the best-performing checkpoint
side_tokenizer = AutoTokenizer.from_pretrained(checkPointFolder)
side_model = AutoModel.from_pretrained(checkPointFolder).to(SIDE_DEVICE)

def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0]
    input_mask_expanded = attention_mask.unsqueeze(
        -1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

def side(output, code):
    
    pair = [code,output]

    encoded_input = side_tokenizer(
            pair, padding=True, truncation=True, return_tensors='pt').to(SIDE_DEVICE)

    # Compute token embeddings
    with torch.no_grad():
        model_output = side_model(**encoded_input)

    # Perform pooling
    sentence_embeddings = mean_pooling(
        model_output, encoded_input['attention_mask'])

    # Normalize embeddings
    sentence_embeddings = F.normalize(sentence_embeddings, p=2, dim=1)

    sim = util.pytorch_cos_sim(
        sentence_embeddings[0], sentence_embeddings[1]).item()
    
    return sim


@retry(Exception, tries=5, delay=1, backoff=2, max_delay=120)
def llm_judge_gpt(model_name, code, summary, temperature, top_p, max_new_tokens):
    openai.api_key=chatgpt_api_key
    
    prompt = '''You are an expert in understanding python code. Your task is to rate the factual consistency of a summarized text generated from a python code.
Factual consistent summary guarantees that the summary remains consistent with the python code, accurately capturing its primary functionality and logic without adding any unrelated content.
Please refer to the PYTHON CODE, and the SUMMARY, and score the consistency of the summary on a scale of 1 to 5.
Generate ONLY the score. Do not include any other codes, or notes.

### PYTHON CODE:
{x}
### SUMMARY: {text}
### SCORE:
'''
    
    user_input_script=prompt['system_prompt']+prompt['user_prompt']
    user_input_script=user_input_script.replace('{x}', code)
    user_input_script=user_input_script.replace('{text}', summary)
    
    response = openai.ChatCompletion.create(
        model=model_name,
        temperature = temperature,
        top_p=top_p,
        max_tokens=max_new_tokens,
        messages=[
            {"role": "user",  
             "content": user_input_script}
        ]
    )

    output_text = response["choices"][0]["message"]["content"].strip()

    return int(output_text)


import numpy as np
import pandas as pd
from collections import Counter
from itertools import combinations

def nominal_metric(a, b):
    return 0 if a == b else 1

def disagreement_matrix(data, distance_fn=nominal_metric):
    n = len(data)
    if n < 2:
        return 0.0
    disagreements = 0.0
    total = 0
    for i, j in combinations(range(n), 2):
        disagreements += distance_fn(data[i], data[j])
        total += 1
    return disagreements / total if total else 0.0

def krippendorffs_alpha(data, distance_fn=nominal_metric):
    """
    data: 2D list or np.array with shape (num_raters, num_items)
    distance_fn: function defining the difference between two values
    """
    data = np.array(data)
    n_items = data.shape[1]
    
    # Step 1: Observed Disagreement Do
    Do_total = 0
    units_with_data = 0
    for col in data.T:
        ratings = [r for r in col if r is not None]
        if len(ratings) >= 2:
            Do_total += disagreement_matrix(ratings, distance_fn)
            units_with_data += 1
    Do = Do_total / units_with_data if units_with_data else 0.0

    # Step 2: Expected Disagreement De
    all_ratings = [r for r in data.flatten() if r is not None]
    counter = Counter(all_ratings)
    total = sum(counter.values())

    De = 0.0
    for (v1, v2) in combinations(counter.keys(), 2):
        De += distance_fn(v1, v2) * counter[v1] * counter[v2]
    for v in counter.keys():
        De += distance_fn(v, v) * counter[v] * (counter[v] - 1) / 2
    De *= 2 / (total * (total - 1)) if total > 1 else 0.0

    # Final α
    if De == 0:
        return 1.0  # Perfect agreement
    return 1 - Do / De


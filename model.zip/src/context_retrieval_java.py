import os
import re
import json
from tqdm import tqdm
from argparse import ArgumentParser
from termcolor import cprint
from typing import Dict, List, Tuple, Set
import ast


def extract_imports_from_java(file_content: str) -> List[Tuple[str, str]]:
    """
    Java 파일 내용에서 import 문들을 추출합니다.
    
    Returns:
        import 문들의 리스트, 각 항목은 (import_statement, module_path)
        예: ("import java.util.ArrayList;", "java.util.ArrayList")
    """
    imports = []
    
    # Java import 패턴: import java.util.ArrayList; 또는 import java.util.*;
    import_pattern = r'import\s+(static\s+)?([\w\.]+(?:\.\*)?)\s*;'
    
    matches = re.finditer(import_pattern, file_content)
    
    for match in matches:
        is_static = match.group(1) is not None
        import_path = match.group(2)
        static_prefix = "static " if is_static else ""
        import_statement = f"import {static_prefix}{import_path};"
        imports.append((import_statement, import_path))
    
    return imports


def extract_method_calls_and_attributes(code: str) -> Set[str]:
    """
    Java 코드에서 메서드 호출과 속성 접근을 추출합니다.
    예: obj.method(), Class.staticMethod(), obj.property
    """
    identifiers = set()
    
    # 메서드 호출 패턴: word.word(...) 
    method_pattern = r'([a-zA-Z_]\w*(?:\.[a-zA-Z_]\w*)+)\s*\('
    # 속성 접근 패턴: word.word
    property_pattern = r'([a-zA-Z_]\w*\.[a-zA-Z_]\w*)'
    
    for match in re.finditer(method_pattern, code):
        identifiers.add(match.group(1))
    
    for match in re.finditer(property_pattern, code):
        identifiers.add(match.group(1))
    
    return identifiers


def extract_used_classes_from_code(code: str) -> Set[str]:
    """
    Java 코드에서 사용된 클래스들을 추출합니다.
    """
    used_items = set()
    
    # 클래스 생성 패턴: new ClassName
    new_pattern = r'new\s+([a-zA-Z_]\w*)'
    for match in re.finditer(new_pattern, code):
        used_items.add(match.group(1))
    
    # Cast 패턴: (ClassName)
    cast_pattern = r'\(([a-zA-Z_]\w*)\)\s'
    for match in re.finditer(cast_pattern, code):
        used_items.add(match.group(1))
    
    # 타입 선언 패턴: ClassName var
    type_pattern = r'(?:public|private|protected|static|final|\s)([A-Z][a-zA-Z_]\w*)\s+[a-zA-Z_]\w*(?:\s|;|,|=|\))'
    for match in re.finditer(type_pattern, code):
        used_items.add(match.group(1))
    
    return used_items


def classify_imports(imports: List[Tuple[str, str]], package_name: str) -> Tuple[List[Tuple[str, str]], List[Tuple[str, str]]]:
    """
    import들을 external과 internal로 분류합니다.
    
    Args:
        imports: (import_statement, import_path) 튜플의 리스트
        package_name: 현재 파일의 패키지명 (예: java.util)
    
    Returns:
        (external_imports, internal_imports)
    """
    external_imports = []
    internal_imports = []
    
    # 표준 라이브러리 패키지들
    standard_packages = {
        'java.', 'javax.', 'org.w3c.', 'org.xml.', 'org.omg.', 'sun.',
        'com.sun.'
    }
    
    for import_stmt, import_path in imports:
        # Wildcard import 무시
        if import_path.endswith('.*'):
            full_import = import_path
        else:
            full_import = import_path
        
        # 표준 라이브러리 판정
        is_standard = any(full_import.startswith(std_pkg) for std_pkg in standard_packages)
        
        # 현재 패키지의 다른 파일에서 import하는 경우
        if full_import.startswith(package_name) and not is_standard:
            internal_imports.append((import_stmt, full_import))
        else:
            external_imports.append((import_stmt, full_import))
    
    return external_imports, internal_imports


def extract_class_name_from_code(code: str) -> str:
    """
    Java 코드에서 클래스명을 추출합니다.
    """
    class_pattern = r'(?:public|private|protected)?\s*(?:abstract)?\s*(?:final)?\s*class\s+([a-zA-Z_]\w*)'
    match = re.search(class_pattern, code)
    if match:
        return match.group(1)
    return ""


def extract_field_and_method_names(file_content: str) -> Dict[str, str]:
    """
    Java 파일에서 필드와 메서드 정의를 추출합니다.
    """
    items = {}
    
    # 필드 패턴: type name;
    field_pattern = r'(?:private|public|protected|static|final|\s)+([a-zA-Z_]\w*(?:<[^>]*>)?)\s+([a-zA-Z_]\w*)\s*(?:=|;)'
    
    # 메서드 패턴: returnType methodName(params)
    method_pattern = r'(?:public|private|protected|static|final|\s)+(?:[\w<>,\s]+)\s+([a-zA-Z_]\w*)\s*\('
    
    for match in re.finditer(field_pattern, file_content):
        field_type = match.group(1)
        field_name = match.group(2)
        items[field_name] = field_type
    
    for match in re.finditer(method_pattern, file_content):
        method_name = match.group(1)
        if method_name not in items:  # 이미 있으면 필드 정보를 유지
            items[method_name] = 'method'
    
    return items


def remove_java_comments(code_string: str) -> str:
    """
    Java 코드에서 주석을 제거합니다.
    - 한 줄 주석: //
    - 여러 줄 주석: /* */
    - JavaDoc 주석: /** */
    """
    # 여러 줄 주석 제거 (/** */ 포함)
    code_string = re.sub(r'/\*[\s\S]*?\*/', '', code_string)
    
    # 한 줄 주석 제거
    code_string = re.sub(r'//.*?$', '', code_string, flags=re.MULTILINE)
    
    return code_string


def context_retriever_java(idx: int, dataset: List[Dict]) -> Tuple[Dict, List[Tuple], Dict]:
    """
    Java 코드에 대한 context information을 추출합니다.
    
    Args:
        idx: 데이터셋 인덱스
        dataset: CoderEval4Java 데이터셋
    
    Returns:
        (related_information, external_doc, proj_info)
    """
    record = dataset[idx]
    
    # 기본 정보 추출
    file_content = record.get('file_content', '')
    code = record.get('code', '')
    package_name = record.get('package', '')
    class_name = record.get('class_name', '')
    lineno = record.get('lineno', 1)
    end_lineno = record.get('end_lineno', 1)
    
    # 주석 제거
    file_content_cleaned = remove_java_comments(file_content)
    code_cleaned = remove_java_comments(code)
    
    # Import 정보 추출
    imports = extract_imports_from_java(file_content_cleaned)
    
    # Import 분류
    external_imports, internal_imports = classify_imports(imports, package_name)
    
    # 코드에서 사용되는 항목 추출
    method_calls = extract_method_calls_and_attributes(code_cleaned)
    used_classes = extract_used_classes_from_code(code_cleaned)
    
    # 파일에서 정의된 필드/메서드
    defined_items = extract_field_and_method_names(file_content_cleaned)
    
    related_information = {}
    external_doc = []
    
    # 각 사용된 항목에 대해 관련 정보 추출
    all_used_items = method_calls | used_classes
    
    for item in all_used_items:
        # 점이 포함된 qualified name은 분해
        parts = item.split('.')
        simple_name = parts[-1] if parts else item
        
        # External import에서 찾기
        found_external = []
        for import_stmt, import_path in external_imports:
            # 정확한 매치 또는 와일드카드 매치
            if import_path.endswith('.*'):
                # java.util.* 형태
                possible_match = f"{import_path[:-2]}{simple_name}"
                found_external.append((import_stmt, possible_match))
            elif import_path.endswith(simple_name):
                # java.util.ArrayList 형태
                found_external.append((import_stmt, import_path))
        
        if found_external:
            related_information[item] = {
                'var_name': item,
                'node_entity': 'external_call' if '(' in str(method_calls) else 'external_reference',
                'info_type': 'external',
                'info': found_external
            }
            external_doc.extend(found_external)
        
        # Internal import에서 찾기
        found_internal = []
        for import_stmt, import_path in internal_imports:
            if import_path.endswith(simple_name) or import_path.endswith(f".{simple_name}"):
                found_internal.append((import_path, simple_name))
        
        if found_internal:
            related_information[item] = {
                'var_name': item,
                'node_entity': 'internal_call' if '(' in str(method_calls) else 'internal_reference',
                'info_type': 'internal',
                'info': found_internal
            }
        
        # 같은 파일 내 정의 찾기
        if simple_name in defined_items:
            current_file_path = f"{package_name}.{class_name}"
            related_information[item] = {
                'var_name': item,
                'node_entity': 'internal_definition',
                'info_type': 'internal',
                'info': [(current_file_path, simple_name)]
            }
    
    # proj_info 구성
    proj_info = {
        'package': package_name,
        'class_name': class_name,
        'file_path': record.get('repo_path', ''),
        'project': record.get('project', '')
    }
    
    
    
    return related_information, external_doc, proj_info


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('--file', required=True, type=str, help='input CoderEval4Java.json file')
    parser.add_argument('--output', required=True, type=str, help='output file for context-enriched dataset')
    args = parser.parse_args()
    
    # 데이터 로딩
    with open(args.file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    records = data.get('RECORDS', [])
    print(f'There are {len(records)} samples in CoderEval4Java.')
    
    # 각 레코드에 대해 context 정보 추출
    for idx in tqdm(range(len(records))):
        try:
            related_information, external_doc, proj_info = context_retriever_java(idx, records)
            
            print(related_information)
            
            # 결과 저장
            records[idx]['related_information'] = related_information
            records[idx]['external_doc'] = list(set(external_doc))
            records[idx]['proj_info'] = proj_info
            
        except Exception as e:
            cprint(f"Error processing record {idx}: {str(e)}", "red")
            records[idx]['related_information'] = {}
            records[idx]['external_doc'] = []
            records[idx]['proj_info'] = {}
    
    # 결과 저장
    output_data = {'RECORDS': records}
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)
    
    print(f"Context information saved to {args.output}")
